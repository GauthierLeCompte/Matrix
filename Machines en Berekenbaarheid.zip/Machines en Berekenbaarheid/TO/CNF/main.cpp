#include <iostream>
#include "single_include/nlohmann/json.hpp"
#include "Classes/CFG.h"
#include <fstream>

int main() {

    std::cout << "test" << std::endl;
    CFG* cfg = new CFG("CFG8.json");

    std::ofstream file;
    file.open ("../output/CNF.txt");
    cfg->CNF(file);
    file.close();
}