#include "CFG.h"
#include "math.h"
#include "random"
#include <set>
using json = nlohmann::json;

CFG::CFG(std::string file) {
    this->file = "../input/" + file;
    Parse();
}

void CFG::Parse() {
    //Read json
    std::ifstream ifs(file);
    json j = json::parse(ifs);

    //Read state, transition and alphabet
    std::string start = j["Start"];
    std::vector<std::vector<std::string>> productions;
    std::vector<std::string> variables = j["Variables"];
    std::vector<std::string> terminals = j["Terminals"];
    json::array_t prod = j["Productions"];

    for(auto i :prod) {
        std::vector<std::string> production;
        std::string name = i["head"];
        std::vector<std::string> body = i["body"];

        production.push_back(name);

        for (int k = 0; k < body.size(); ++k) {
            production.push_back(body[k]);
        }

        productions.push_back(production);
    }

    setVariables(variables);
    setStartVariables(variables);
    setTerminals(terminals);
    setProductions(productions);
    setStart(start);
}

void CFG::print(std::ofstream& textfile) {
    for (int i = 0; i < this->getVariables().size(); ++i) {
        textfile << this->getVariables()[i] << " -> ";

        for (int j = 0; j < this->getProductions().size(); ++j) {
            if (this->getProductions()[j][0] == this->getVariables()[i]) {

                for (int k = 1; k < this->getProductions()[j].size(); ++k) {
                    if (this->getProductions()[j][k] == "") {
                        textfile << "epsilon";
                    }
                    else {
                        textfile << this->getProductions()[j][k];
                    }
                }
                textfile << " | ";
            }
        }
        textfile << std::endl;
    }
    textfile << std::endl;
}

void CFG::CNF(std::ofstream& textfile) {
    textfile << "Context Free Grammar:" << std::endl;
    textfile << "Start: " << this->getStart() <<std::endl;
    textfile << "Variables: ";
    for (int i = 0; i < this->getVariables().size(); ++i) {
        textfile << this->getVariables()[i] << " | ";
    }
    textfile << std::endl;
    textfile << "Terminals: ";
    for (int i = 0; i < this->getTerminals().size(); ++i) {
        textfile << this->getTerminals()[i] << " | ";
    }
    textfile << std::endl; textfile << std::endl;
    textfile << "Productions: " << std::endl;
    this->print(textfile);

    textfile << "------------------------------------------------------- " << std::endl;
    textfile << std::endl;

    textfile << "1) Eliminate epsilon productions:" << std::endl;
    newStartVar(textfile);
    eliminateEpsilon(textfile);
    textfile << "------------------------------------------------------- " << std::endl;
    textfile << std::endl;

    textfile << "2) Remove unit productions:" << std::endl;
    removeUnitProductions(textfile);
    textfile << "------------------------------------------------------- " << std::endl;
    textfile << std::endl;

    textfile << "3) Remove unreachable variables:" << std::endl;
    removeUnreachebleVariables(textfile);
    removeNonExistingVariables(textfile);
    textfile << "------------------------------------------------------- " << std::endl;
    textfile << std::endl;

    textfile << "4) Remove non-generating variables:" << std::endl;
    removeNonGeneratingVariables(textfile);
    textfile << "------------------------------------------------------- " << std::endl;
    textfile << std::endl;

    textfile << "5) Replace terminals with variables from productions where |body| > 1:" << std::endl;
    changeTerminalsInProduction(textfile);
    textfile << "------------------------------------------------------- " << std::endl;
    textfile << std::endl;

    textfile << "6) Replace variables with other variables from productions where |body| > 2" << std::endl;
    changeDoubleVariables(textfile);
    textfile << "------------------------------------------------------- " << std::endl;
    textfile << std::endl;

    textfile << "Final productions:" << std::endl;
    this->print(textfile);
}

void CFG::newStartVar(std::ofstream &textfile) {
    std::vector<std::vector<std::string>> newProductions;
    std::vector<std::string> newStartVariables;
    std::vector<std::string> newVariables;


    newVariables.push_back("S0");
    newProductions.push_back({"S0", "S"});

    for (int i = 0; i < this->getStartVariables().size(); ++i) {
        newStartVariables.push_back(this->getStartVariables()[i]);
    }

    for (int j = 0; j< this->getVariables().size(); ++j) {
        newVariables.push_back(this->getVariables()[j]);
    }

    for (int k = 0; k < this->getProductions().size(); ++k) {
        newProductions.push_back(this->getProductions()[k]);
    }

    this->setStart("S0");
    this->setStartVariables(newStartVariables);
    this->setProductions(newProductions);
    this->setVariables(newVariables);
}

void CFG::eliminateEpsilon(std::ofstream& textfile) {
    for (int l = 0; l < this->getVariables().size(); ++l) {
        int count = 0;

        for (int i = 0; i < this->getProductions().size(); ++i) {
            if (this->getProductions()[i][0] == this->getVariables()[l]) {
                count ++;
            }
        }
    }

    for (int i = 0; i < this->getProductions().size(); i++) {
        //Check if productions[i] is a epsilone transition
        if (symbolInProduction(this->getProductions()[i], "")) {
            //Symbol = head of the epsilon production (S -> epsilon; S = head)
            std::string symbol = this->getProductions()[i][0];

            //Delete epsilon production and update other productions where "symbol" in occurs
            deleteProduction(this->getProductions(), i);
            updateAfterEpsilonDeletion(this->getProductions(), symbol);
            i = -1;

            textfile << "After removing " << symbol << " -> " << "epsilon:" << std::endl;
            this->print(textfile);
        }
    }
}

void CFG::updateAfterEpsilonDeletion(std::vector<std::vector<std::string>> &productions, std::string symbol) {
    std::vector<std::vector<std::string>> tempProductions;
    std::vector<std::vector<std::string>> productionsFromSymbol = getProductionWhereSymbolInOccurs(symbol);

    for (int i = 0; i < productionsFromSymbol.size(); ++i) {
        for (int j = 1; j < productionsFromSymbol[i].size(); ++j) {
            if (productionsFromSymbol[i][j] == symbol) {
                std::vector<std::string> tempProduction = productionsFromSymbol[i];

                deleteStringInVector(tempProduction, j);

                if (tempProduction.size() == 1) {
                    tempProduction.push_back("");
                }

                productionsFromSymbol.push_back(tempProduction);

                if (!(std::find(productions.begin(), productions.end(), tempProduction) != productions.end())) {
                    productions.push_back(tempProduction);
                }
            }
        }
    }
}

std::vector<std::vector<std::string>> CFG::getProductionWhereSymbolInOccurs(std::string symbol) {
    std::vector<std::vector<std::string>> allProductions;

    for (int i = 0; i < this->getProductions().size(); ++i) {
        for (int j = 1; j < this->getProductions()[i].size(); ++j) {
            if (this->getProductions()[i][j] == symbol) {
                allProductions.push_back(this->getProductions()[i]);
                break;
            }
        }
    }

    return allProductions;
}

std::vector<std::vector<std::string>> CFG::getProductionWithSymbolAsHead(std::string symbol) {
    std::vector<std::vector<std::string>> allProductions;

    for (int i = 0; i < this->getProductions().size(); ++i) {
        for (int j = 1; j < this->getProductions()[i].size(); ++j) {
            if (this->getProductions()[i][0] == symbol) {
                allProductions.push_back(this->getProductions()[i]);
                break;
            }
        }
    }

    return allProductions;
}

void CFG::deleteProduction(std::vector<std::vector<std::string>>& productions, int i) {
    productions.erase(productions.begin() + i);
}

bool CFG::symbolInProduction(std::vector<std::string> production, std::string symbol) {
    for (int i = 0; i < production.size(); ++i) {
        if (production[i] == symbol && i != 0) {
            return true;
        }
    }

    return false;
}

void CFG::removeUnitProductions(std::ofstream& textfile) {
    //If you have a unit production of the form S -> S, only delete this production
    for (int l = 0; l < this->getProductions().size(); ++l) {
        if (isUnitProduction(this->getProductions()[l])) {
            if (this->getProductions()[l][0] == this->getProductions()[l][1]) {
                std::string head = this->getProductions()[l][0];
                std::string body = this->getProductions()[l][1];

                deleteProduction(this->getProductions(), l);
                l = -1;

                textfile << "After removing " << head << " -> " << body << std::endl;
                this->print(textfile);
            }
        }
    }
    for (int i = 0; i < this->getProductions().size(); ++i) {
        //Check if production is a unit production
        if (isUnitProduction(this->getProductions()[i])) {
            std::string head = this->getProductions()[i][0];
            std::string body = this->getProductions()[i][1];

            std::string symbol = this->getProductions()[i][1];
            std::vector<std::vector<std::string>> tempProductions;
            std::vector<std::vector<std::string>> allProductions = getAllProductionsFromSymbol(this->getProductions()[i][1]);

            //Make new productions
            for (int j = 0; j < allProductions.size(); ++j) {
                std::vector<std::string> newProduction;
                newProduction.push_back(this->getProductions()[i][0]);

                for (int k = 1; k < allProductions[j].size(); ++k) {
                    newProduction.push_back(allProductions[j][k]);
                }

                tempProductions.push_back(newProduction);
            }

            //Delete original unit production
            deleteProduction(this->getProductions(), i);

            //Check if production already exists and add new productions
            for (int m = 0; m < tempProductions.size(); ++m) {
                if (!(std::find(this->getProductions().begin(), this->getProductions().end(), tempProductions[m]) != this->getProductions().end())) {
                    this->getProductions().push_back(tempProductions[m]);
                }
            }

            i = -1; //Repeat this loop untill no more unit productions

            textfile << "After removing " << head << " -> " << body << std::endl;
            this->print(textfile);
        }
    }
}

std::vector<std::vector<std::string>> CFG::getAllProductionsFromSymbol(std::string symbol) {
    std::vector<std::vector<std::string>> allProductions;

    for (int i = 0; i < this->getProductions().size(); ++i) {
        if (this->getProductions()[i][0] == symbol) {
            allProductions.push_back(this->getProductions()[i]);
        }
    }

    return allProductions;
}

bool CFG::isUnitProduction(std::vector<std::string> production) {
    if (production.size() == 2) {
        for (int i = 0; i < this->getVariables().size(); ++i) {
            if (production[1] == this->getVariables()[i]) {
                return true;
            }
        }
    }

    return false;
}

void CFG::removeUnreachebleVariables(std::ofstream& textfile) {
    int count = 0;

    //Check for every variable
    for (int i = 0; i < this->getVariables().size(); ++i) {
        bool reached = false;

        //Start state is always reached
        if (this->getVariables()[i] == this->getStart()) {
            reached = true;
        }
        else {
            for (int j = 0; j < this->getProductions().size(); ++j) {
                for (int k = 1; k < this->getProductions()[j].size(); ++k) {
                    if (this->getVariables()[i] == this->getProductions()[j][k] && this->getProductions()[j][0] != this->getProductions()[j][k]) {
                        reached = true;
                    }
                }
            }
        }

        //If not reached, delete every production with head variables[i] and delete symbol from variables
        if (!reached) {
            count ++;

            for (int j = 0; j < this->getProductions().size(); ++j) {
                if (this->getProductions()[j][0] == this->getVariables()[i]) {
                    deleteProduction(this->getProductions(), j);
                    j--;
                }
            }

            std::string head = this->getVariables()[i];
            deleteStringInVector(this->getVariables(), i);
            textfile << "After removing all production from " << head << std::endl;
            this->print(textfile);
        }
    }

    if (count == 0) {
        textfile << "All variables are reachable" << std::endl;
        textfile << std::endl;
    }
}

void CFG::deleteStringInVector(std::vector<std::string>& variables, int index) {
    variables.erase(variables.begin() + index);
}

void CFG::removeNonExistingVariables(std::ofstream& textfile) {
    //Check for every symbol in body if it is a variable or terminal
    for (int i = 0; i < this->getProductions().size(); ++i) {
        for (int j = 0; j < this->getProductions()[i].size(); ++j) {
            //If symbol is no terminal or variable; delete
            if (!(isTerminal(this->getProductions()[i][j]) || isVariable(this->getProductions()[i][j]))) {
                std::string head = this->getProductions()[i][j];

                deleteProduction(this->getProductions(), i);

                textfile << head << " is no variable or terminal and the production " << head << " -> ";

                for (int k = 1; k < this->getProductions()[i].size(); ++k) {
                    textfile << this->getProductions()[i][k];
                }
                textfile << "is deleted" << std::endl;
                this->print(textfile);
            }
        }
    }
}

bool CFG::isVariable(std::string symbol) {
    return std::find(this->getVariables().begin(), this->getVariables().end(), symbol) != this->getVariables().end();
}

void CFG::removeNonGeneratingVariables(std::ofstream& textfile) {
    std::vector<std::string> generatingVariables;

    for (int j = 0; j < this->getVariables().size(); ++j) {
        for (int i = 0; i < this->getVariables().size(); ++i) {
            std::vector<std::vector<std::string>> allProductions = getProductionWithSymbolAsHead(this->getVariables()[i]);
            if (isGenerating(allProductions, generatingVariables)) {
                textfile << this->getVariables()[i] << " is generating" << std::endl;
                textfile << std::endl;
            }
        }
    }

    for (int k = 0; k < this->getVariables().size(); ++k) {
        if (!(std::find(generatingVariables.begin(), generatingVariables.end(), this->getVariables()[k]) != generatingVariables.end())) {

            textfile << this->getVariables()[k] << " is non-generating so we delete all productions with this variable" << std::endl;
            this->print(textfile);

            for (int i = 0; i < this->getProductions().size(); ++i) {
                for (int j = 0; j < this->getProductions()[i].size(); ++j) {
                    if (this->getProductions()[i][j] == this->getVariables()[k]) {
                        deleteProduction(this->getProductions(), i);
                    }
                }
            }

            deleteStringInVector(this->getVariables(), k);
        }
    }
}

bool CFG::isGenerating(std::vector<std::vector<std::string>> productions, std::vector<std::string>& generatingVariables) {
    for (int i = 0; i < productions.size(); ++i) {
        int count = 0;

        for (int j = 1; j < productions[i].size(); ++j) {
            if (isTerminal(productions[i][j]) ||
            std::find(generatingVariables.begin(), generatingVariables.end(), productions[i][j]) != generatingVariables.end()) {
                count ++;
            }
        }

        if (count == productions[i].size() - 1) {
            if (!(std::find(generatingVariables.begin(), generatingVariables.end(), productions[i][0]) != generatingVariables.end())) {
                generatingVariables.push_back(productions[i][0]);
                return true;
            }
        }
    }
    return false;
}

void CFG::changeTerminalsInProduction(std::ofstream& textfile) {

    for (int i = 0; i < this->getProductions().size(); ++i) {
        for (int j = 1; j < this->getProductions()[i].size(); ++j) {
            if (this->getProductions()[i].size() - 1 > 1 && isTerminal(this->getProductions()[i][j])) {

                textfile << "After changing " << this->getProductions()[i][0] << " -> ";
                for (int k = 1; k < this->getProductions()[i].size(); ++k) {
                    textfile << this->getProductions()[i][k];
                }

                if (productionWithTerminalExists(this->getProductions()[i][j], this->getProductions()[i])) {
                    fixProductionExists(this->getProductions()[i], this->getProductions()[i][j], j);
                }
                else {
                    fixProductionNoExists(this->getProductions()[i], this->getProductions()[i][j], j);
                }

                textfile << " to " << this->getProductions()[i][0] << " -> ";
                for (int k = 1; k < this->getProductions()[i].size(); ++k) {
                    textfile << this->getProductions()[i][k];
                }
                textfile << std::endl;
                this->print(textfile);
            }
        }
    }
}

void CFG::fixProductionExists(std::vector<std::string>& production, std::string symbol, int index) {
    for (int i = 0; i < this->getProductions().size(); ++i) {
        if (this->getProductions()[i].size() == 2) {
            if (this->getProductions()[i][1] == symbol) {
                production[index] = this->getProductions()[i][0];
            }
        }
    }
}

void CFG::fixProductionNoExists(std::vector<std::string> &production, std::string symbol, int index) {
    std::vector<std::string> newProduction;
    std::string head = generateRandomSymbol();
    newProduction.push_back(head);
    newProduction.push_back(symbol);

    production[index] = head;
    this->getProductions().push_back(newProduction);
}

std::string CFG::generateRandomSymbol() {
    char c;

    for (int i = 0; i < INFINITY; ++i) {
        c = 'A' + i;
        bool inVariables = false;
        std::string temp(1, c);

        for (int j = 0; j < this->getVariables().size(); ++j) {
            if (this->getVariables()[j] == temp) {
                inVariables = true;
                break;
            }
        }

        if (!inVariables) {
            this->getVariables().push_back(temp);
            return  temp;
        }
    }

    return "";
}

bool CFG::productionWithTerminalExists(std::string symbol, std::vector<std::string>& production) {
    for (int i = 0; i < this->getProductions().size(); ++i) {
        if (this->getProductions()[i].size() == 2) {
            if (this->getProductions()[i][1] == symbol && !symbolInStartVariables(this->getProductions()[i][0])) {
                return true;
            }
        }
    }

    return false;
}

bool CFG::symbolInStartVariables(std::string var) {
    for (int i = 0; i < this->getStartVariables().size(); ++i) {
        if (startVariables[i] == var) {
            return true;
        }
    }

    return false;
}

bool CFG::isTerminal(std::string symbol) {
    return std::find(this->getTerminals().begin(), this->getTerminals().end(), symbol) != this->getTerminals().end();
}

void CFG::changeDoubleVariables(std::ofstream &textfile) {
    for (int i = 0; i < this->getProductions().size(); ++i) {
        if (this->getProductions()[i].size() - 1 > 2) {
            fixProduction(this->getProductions()[i], textfile);
        }
    }
}

void CFG::fixProduction(std::vector<std::string> &production, std::ofstream &textfile) {
    std::vector<std::string> replacedSymbols;
    std::vector<std::string> test =  production;
    bool exists = false;

    textfile << "After changing " << production[0] << " -> ";
    for (int k = 1; k < production.size(); ++k) {
        textfile << production[k];
    }

    //Delete original production and add all removed symbol to string to check later on if they already have a production
    for (int i = 2; i < production.size(); ++i) {
        replacedSymbols.push_back(production[i]);
        deleteStringInVector(production, i);
        deleteStringInVector(test,i);
        i--;
    }

    //Check if the string of replaced symbols already have a production
    for (int j = 0; j < this->getProductions().size(); ++j) {
        int count = 0;

        if (!symbolInStartVariables(this->getProductions()[j][0])) {
            for (int i = 0; i < replacedSymbols.size(); ++i) {
                if (this->getProductions()[j][i+1] == replacedSymbols[i]) {
                    count++;
                }
            }

            if (count == replacedSymbols.size()) {
                production.push_back(this->getProductions()[j][0]);
                exists = true;
            }
        }
    }

    //If it hasn't; Make new production
    if (!exists) {
        std::vector<std::string> newProduction;
        std::string head = generateRandomSymbol();
        production.push_back(head);
        test.push_back(head);
        newProduction.push_back(head);
        for (int i = 0; i < replacedSymbols.size(); ++i) {
            newProduction.push_back(replacedSymbols[i]);
        }

        this->getProductions().push_back(newProduction);
    }

    textfile << " to " << test[0] << " -> " << test[1] << test[2];
    textfile << std::endl;
    this->print(textfile);
}

std::vector<std::string> &CFG::getVariables() {
    return variables;
}

void CFG::setVariables(const std::vector<std::string> &variables) {
    CFG::variables = variables;
}

const std::vector<std::string> &CFG::getTerminals() const {
    return terminals;
}

void CFG::setTerminals(const std::vector<std::string> &terminals) {
    CFG::terminals = terminals;
}

std::vector<std::vector<std::string>> &CFG::getProductions() {
    return productions;
}

void CFG::setProductions(const std::vector<std::vector<std::string>> &productions) {
    CFG::productions = productions;
}

const std::string &CFG::getStart() const {
    return start;
}

void CFG::setStart(const std::string &start) {
    CFG::start = start;
}

const std::vector<std::string> &CFG::getStartVariables() const {
    return startVariables;
}

void CFG::setStartVariables(const std::vector<std::string> &startVariables) {
    CFG::startVariables = startVariables;
}
