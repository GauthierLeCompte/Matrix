//
// Created by Gauthier Le Compte on 01/11/2018.
//

#ifndef CHOMSKY_NORMAL_FORM_PARSER_H
#define CHOMSKY_NORMAL_FORM_PARSER_H

#include <vector>
#include <iostream>
#include <fstream>
#include "../single_include/nlohmann/json.hpp"

class CFG {
private:
    std::string file;
    std::string start;
    std::vector<std::string> startVariables;
    std::vector<std::string> variables;
    std::vector<std::string> terminals;
    std::vector<std::vector<std::string>> productions;

public:
    /**
     * Constructor for CFG which immediatly parses the CFG
     * @param file CFG file
     */
    CFG(std::string file);

    /**
     * Function that parses the CFG
     */
    void Parse();

    /**
     * Prints the CFG
     */
    void print(std::ofstream& textfile);

    /**
     * Converts CFG to CNF
     */
    void CNF(std::ofstream& textfile);

    /**
     * Makes new start variable
     * @param textfile File we print to
     */
    void newStartVar(std::ofstream& textfile);

    /**
     * Eliminates all epsilon productions
     */
    void eliminateEpsilon(std::ofstream& textfile);

    /**
     * Updates the productions after the epsilon production is deleted
     * @param productions Every production rule from the CFG
     * @param symbol The head of the production from which we are going to remove an epsilon production
     */
    void updateAfterEpsilonDeletion(std::vector<std::vector<std::string>>& productions, std::string symbol);

    /**
     * Returns all the production where for example the symbol "A" in occurs
     * @param symbol the symbol we want the productions of
     * @return All the productions
     */
    std::vector<std::vector<std::string>> getProductionWhereSymbolInOccurs(std::string symbol);

    /**
     * Deletes a certain production at index i in the productions vector<vector>>
     * @param productions Every production rule from the CFG
     * @param i Offset from the production to delete
     */
    void deleteProduction(std::vector<std::vector<std::string>>& productions, int i);

    /**
     * Checks if a certain symbol is in a production
     * @param production Production rule
     * @param symbol Symbol we have to check is in the production
     * @return True or false
     */
    bool symbolInProduction(std::vector<std::string> production, std::string symbol);

    /**
     * Removes all the unit productions
     */
    void removeUnitProductions(std::ofstream& textfile);

    /**
     * Checks if a production is a unit production
     * @param production Production we have to check
     * @return True or false
     */
    bool isUnitProduction(std::vector<std::string> production);

    /**
     * Searches all the productions from a certain symbol
     * @param symbol Symbol that has to occur in a production
     * @return All the productions where the symbol in occurs
     */
    std::vector<std::vector<std::string>> getAllProductionsFromSymbol(std::string symbol);

    /**
     * Removes all the unreachable variables
     */
    void removeUnreachebleVariables(std::ofstream& textfile);

    /**
     * Deletes a certain string in a vector
     * @param variables All the variables
     * @param index Offset
     */
    void deleteStringInVector(std::vector<std::string>& variables, int index);

    /**
     * Removes variables which aren't terminals or variables
     * @param textfile File where we write the output to
     */
    void removeNonExistingVariables(std::ofstream& textfile);

    /**
     * Checks if symbol is a variable
     * @param symbol Symbol we have to check
     * @return True or false
     */
    bool isVariable(std::string symbol);

    /**
     * Removes variables and it's string if they aren't generating
     */
    void removeNonGeneratingVariables(std::ofstream& textfile);

    /**
     * Checks if a production is generating
     * @param production Production which we have to check
     * @return True or false
     */
    bool isGenerating(std::vector<std::vector<std::string>> productions, std::vector<std::string>& generatingVariables);

    /**
     * Changes terminals into variables from productions with |body| > 1
     */
    void changeTerminalsInProduction(std::ofstream& textfile);

    /**
     * Checks if there is a production that goes from Variable -> terminal (symbol)
     * @param symbol The terminal
     * @return True or false
     */
    bool productionWithTerminalExists(std::string symbol, std::vector<std::string>& production);

    /**
     * If there is a terminal in the body from which there is a existing production, change the terminal with the head of the existing production
     * @param production Production we have to check
     * @param symbol The symbol
     * @param index Offset
     */
    void fixProductionExists(std::vector<std::string>& production, std::string symbol, int index);

    /**
     * If there is a terminal in the body from which there isn't a existing production, make a new production and change the terminal with new variable
     * @param production Production we have to check
     * @param symbol The symbol
     * @param index Offset
     */
    void fixProductionNoExists(std::vector<std::string>& production, std::string symbol, int index);

    /**
     * Checks if a variable was in the original vector of variables
     * @param var The variable we have to check
     * @return True or false
     */
    bool symbolInStartVariables(std::string var);

    /**
     * Generates a random string that isn't used yet for when we need to make a new production
     * @return
     */
    std::string generateRandomSymbol();

    /**
     * Checks if a certain symbol is a terminal
     * @param symbol The symbol we have to check
     * @return True or false
     */
    bool isTerminal(std::string symbol);

    /**
     * Replace variables with other variables from productions where |body| > 2
     * @param textfile File where we write output to
     */
    void changeDoubleVariables(std::ofstream& textfile);

    /**
     * Updates the productions after removing variables from productions where |body| > 2
     * @param production Current production
     * @param textfile Output
     */
    void fixProduction(std::vector<std::string>& production, std::ofstream &textfile);

    /**
     * Searches productions where 'symbol' is the head
     * @param symbol Head of the productions
     * @return Productions with 'symbol' as head
     */
    std::vector<std::vector<std::string>> getProductionWithSymbolAsHead(std::string symbol);

    /**
     * Returns all the variables from the CFG
     * @return Variables
     */
    std::vector<std::string> &getVariables();

    /**
     * Gives variables a new value
     * @param variables New variables
     */
    void setVariables(const std::vector<std::string> &variables);

    /**
     * Returns all the terminals from the CFG
     * @return Terminals
     */
    const std::vector<std::string> &getTerminals() const;

    /**
     * Gives terminals a new value
     * @param terminals New terminals
     */
    void setTerminals(const std::vector<std::string> &terminals);

    /**
     * Returns all the productions from the CFG
     * @return Productions
     */
    std::vector<std::vector<std::string>> &getProductions();

    /**
     * Gives productions a new value
     * @param productions New productions
     */
    void setProductions(const std::vector<std::vector<std::string>> &productions);

    /**
     * Returns the start symbol of the CFG
     * @return Start symbol
     */
    const std::string &getStart() const;

    /**
     * Gives start a new value
     * @param start New start value
     */
    void setStart(const std::string &start);

    /**
     * Returns all the start variables (variables which where in the CFG when it was parsed)
     * @return Original variables from the CFG
     */
    const std::vector<std::string> &getStartVariables() const;

    /**
     * Gives start variables a new value
     * @param startVariables New start variables value
     */
    void setStartVariables(const std::vector<std::string> &startVariables);
};


#endif //CHOMSKY_NORMAL_FORM_PARSER_H
