#include "Cost.h"
#include "../single_include/nlohmann/json.hpp"
#include <fstream>
using json = nlohmann::json;

int Cost::getInsertCost(std::string input)
{
        if (costs.size() == 0) {
                return insertCost;
        } else {
                for (auto costpair : costs) {
                        if (costpair.first == input) {
                                return costpair.second;
                        }
                }
                return insertCost;
        }
}

int Cost::getDeleteCost() { return deleteCost; }

Cost::Cost() {}

Cost::Cost(std::string file)
{
        std::ifstream ifstr(file);
        json js = json::parse(ifstr);
        deleteCost = js["DeleteCost"];
        json::array_t insertCosts = js["InsertCost"];
        for (auto costpair : insertCosts) {
                const std::string& str0 = costpair[0];
                const int& int1 = costpair[1];
                costs.push_back({str0, int1});
        }
}
