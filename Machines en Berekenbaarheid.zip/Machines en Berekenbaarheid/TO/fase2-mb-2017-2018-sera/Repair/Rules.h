#ifndef SERA_RULES_H
#define SERA_RULES_H

#include "../LR/Parser/LR.h"
#include "RepairItem.h"
#include <memory>

class Rules
{
public:
        /**
         * Constructor for Rules
         */
        Rules();

        /**
         * Destructor for rules
         */
        virtual ~Rules();

        /**
         * Virtual function for the rules
         * @param item Item from where we want to perform an action on
         * @param parser LR Parser
         * @param debug Extended output or not
         * @return Repaired Item object
         */
        virtual std::vector<std::shared_ptr<RepairItem>> rule(std::shared_ptr<RepairItem> item, LR& parser,
                                                              bool debug) = 0;
};

#endif // SERA_RULES_H
