#ifndef SERA_REPAIR_H
#define SERA_REPAIR_H

#include "../LR/Parser/LR.h"
#include "Cost.h"
#include "RepairItem.h"
#include <iostream>
#include <memory>
#include <vector>

class Repair
{
private:
        std::vector<std::shared_ptr<RepairItem>> RepairRule2(std::vector<std::shared_ptr<RepairItem>>);
        LR& parser;
        bool debug;
        int limitRepairs = -1;
        int amountRepairs = 0;
        int insertionLimit = -1;
        int deletionLimit = -1;

        std::shared_ptr<Cost> cost;

        bool leastCost = true;
        int leastCostNotLessCount = 0;

        int SymbolsRegion = 10;

        bool panicmode = true;

public:
        /**
         * Constructor
         * @param parser used
         * @param debug: If the output gives the steps
         */
        Repair(LR& parser, bool debug = false) : parser(parser), debug(debug) { cost = std::make_shared<Cost>(); };

        /**
         * Constructor
         * @param costFile file with costs for the inserts and deletes
         * @param parser used
         * @param debug: If the output gives the steps
         */
        Repair(std::string costFile, LR& parser, bool debug = false) : parser(parser), debug(debug)
        {
                cost = std::make_shared<Cost>(costFile);
        };

        /**
         * Destructor
         */
        ~Repair() = default;

        /**
         * Repairs a certain string
         * @param i is the string to repair
         * @return corrected string if possible
         */
        std::vector<std::string> RepairRule(std::vector<std::string> i);

        /**
         * Vector with correctly repaired items
         */
        std::vector<std::shared_ptr<RepairItem>> repairs;

        /**
         * Sets a limit for the amount of repairs
         * @param limitRepairs
         */
        void setLimitRepairs(int limitRepairs);

        /**
         * Sets a limit for the amount of inserts and deletes
         * @param insLim
         * @param delLim
         */
        void setLimitsInsDels(int insLim, int delLim);

        /**
         * Set if least cost must be used or not
         * @param leastCost
         */
        void setLeastCost(bool leastCost);

        /**
         * returns the parser
         * @return  LR parser
         */
        LR& getParser() const;

        /**
         * Sorts a vector of repairItems by least cost first
         * @param items
         * @return  Vector of repairItems
         */
        std::vector<std::shared_ptr<RepairItem>> sortByLeastCost(std::vector<std::shared_ptr<RepairItem>> items);

        /**
         * Returns the lowest cost found in a vector of RepairItems
         * @param vector
         * @return lowest cost a int
         */
        int getLowestCost(std::vector<std::shared_ptr<RepairItem>> vector);

        /**
         * Returns the amount of correctly parsed symbols
         * @return
         */
        int getSymbolsRegion() const;

        /**
         * Sets the amount of correctly parsed symbols
         * @param SymbolsRegion
         */
        void setSymbolsRegion(int SymbolsRegion);

        /**
         * Returns if panic mode is used
         * @return bool
         */
        bool isPanicmode() const;

        /**
         * Sets if panic mode must be used
         * @param panicmode
         */
        void setPanicmode(bool panicmode);

        /**
         * Returns the amount of inserts and deletes done of a repairItem
         * @param item
         * @return
         */
        std::pair<int, int> getInsDels(std::shared_ptr<RepairItem> item);

        /**
         * Remove repairs that used panic mode if there are repairs that didn't use panic mode
         * @param vector
         */
        void RemoveRepairsPanicModeIfPossible(std::vector<std::shared_ptr<RepairItem>>& vector);

        /**
         * Resets all the variables to its base value
         */
        void reset();
};

#endif // SERA_REPAIR_H
