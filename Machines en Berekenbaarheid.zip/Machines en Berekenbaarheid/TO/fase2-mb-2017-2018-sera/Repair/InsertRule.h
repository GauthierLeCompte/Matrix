#ifndef SERA_INSERTRULE_H
#define SERA_INSERTRULE_H

#include "Rules.h"

class InsertRule : public Rules
{
public:
        /**
         * Constructor for insertion rule
         */
        InsertRule();

        /**
         * Destructor for insertion rule
         */
        ~InsertRule() override;

        /**
         * Insert Rule
         * @param item Item from which we want to insert
         * @param parser LR Parser
         * @param debug Extended output or not
         * @return Repaired Item object
         */
        std::vector<std::shared_ptr<RepairItem>> rule(std::shared_ptr<RepairItem> item, LR& parser,
                                                      bool debug) override;
};

#endif // SERA_INSERTRULE_H
