#include "FMR.h"

FMR::FMR() {}

FMR::~FMR() {}

std::vector<std::shared_ptr<RepairItem>> FMR::rule(std::shared_ptr<RepairItem> item, LR& parser, bool debug)
{
        /*Runs the LR parser until it reaches an other error or until it reaches an accepting state*/
        std::vector<std::string> input = item->getInput();
        std::vector<std::string> stack = item->getStack();
        std::vector<std::string> inputBefore = input;

        // make sure rejecting is false so the parser will work
        parser.setRejecting(false);
        if (debug) {
                parser.file << "<br><br>\n";
                parser.file << "[";
                unsigned int i = 0;
                for (const auto& h : item->getHistory()) {
                        ++i;
                        if (h->type() != "shift") {
                                parser.file << h->type() << " " << h->value();
                                if (i < item->getHistory().size()) {
                                        parser.file << ", ";
                                }
                        }
                }
                parser.file << "]<br>";
        }
        if (debug)
                parser.file << "<TABLE BORDER = \"1\">\n";
        parser.parse2(stack, input, debug, debug);

        int previousParserSymbols = item->getParsedSymbols();
        int parsedSymbols = item->getRepairedInput().size() - input.size() - 1;

        int ps1 = previousParserSymbols + item->getParsedSymbolsBeforeError();
        int ps2 = parsedSymbols + item->getParsedSymbolsBeforeError();
        for (int j = ps1; j < ps2; j++) {
                if (j % 10 == 0 && j != 0) {
                        item->setReset(true);
                }
        }
        item->setParsedSymbols(parsedSymbols);

        if (debug)
                parser.file << "</TABLE>\n";

        // add to history shift
        if (inputBefore.size() > input.size()) {
                std::vector<std::shared_ptr<repair::Action>> history = item->getHistory();
                history.push_back(std::make_shared<repair::Shift>());
                item->setHistory(history);
        }
        // if rejecting update stack and input to the values just before the error
        if (parser.isRejecting()) {
                std::vector<std::vector<std::string>> rejectingVar = parser.getRejectingVar();
                item->setStack(rejectingVar[0]);
                item->setInput(rejectingVar[1]);
        }

        return {item};
}
