#ifndef SERA_COST_H
#define SERA_COST_H

#include <iostream>
#include <vector>

class Cost
{
private:
        int deleteCost = 2;
        int insertCost = 2;
        std::vector<std::pair<std::string, int>> costs = {};

public:
        /**
         * Constructor for cost
         */
        Cost();

        /**
         * Construcot for cost with a file
         * @param file Costs values
         */
        Cost(std::string file);

        /**
         * Returns insert cost
         * @param input input
         * @return integer with insert cost
         */
        int getInsertCost(std::string input);

        /**
         * Returns delete cost
         * @return delete cost
         */
        int getDeleteCost();
};

#endif // SERA_COST_H
