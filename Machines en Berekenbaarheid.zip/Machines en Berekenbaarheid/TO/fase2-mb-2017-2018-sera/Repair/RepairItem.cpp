#include "RepairItem.h"

RepairItem::RepairItem(std::vector<std::string> s, std::vector<std::string> i,
                       std::vector<std::shared_ptr<repair::Action>> h, std::vector<std::string> r)
{
        stack = s;
        input = i;
        history = h;
        repairedInput = r;
}

RepairItem::RepairItem(const RepairItem& that)
    : stack(that.stack), input(that.input), history(that.history), repairedInput(that.repairedInput)
{
}

const std::vector<std::string>& RepairItem::getStack() const { return stack; }

void RepairItem::setStack(const std::vector<std::string>& stack) { RepairItem::stack = stack; }

const std::vector<std::string>& RepairItem::getInput() const { return input; }

void RepairItem::setInput(const std::vector<std::string>& input) { RepairItem::input = input; }

const std::vector<std::shared_ptr<repair::Action>>& RepairItem::getHistory() const { return history; }

void RepairItem::setHistory(const std::vector<std::shared_ptr<repair::Action>>& history)
{
        RepairItem::history = history;
}

const std::vector<std::string>& RepairItem::getRepairedInput() const { return repairedInput; }

void RepairItem::setRepairedInput(const std::vector<std::string>& repairedInput)
{
        RepairItem::repairedInput = repairedInput;
}

void RepairItem::addToCost(int cost) { RepairItem::cost += cost; }

void RepairItem::setCost(int cost) { RepairItem::cost = cost; }

int RepairItem::getCost() const { return cost; }

const std::pair<int, int>& RepairItem::getInsertsDeletes() const { return InsertsDeletes; }

void RepairItem::resetInsertsDeletes() { InsertsDeletes = {0, 0}; }

void RepairItem::setInsertsDeletes(const std::pair<int, int>& InsertsDeletes)
{
        RepairItem::InsertsDeletes = InsertsDeletes;
}

int RepairItem::getParsedSymbolsBeforeError() const { return ParsedSymbolsBeforeError; }

void RepairItem::setParsedSymbolsBeforeError(int ParsedSymbolsBeforeError)
{
        RepairItem::ParsedSymbolsBeforeError = ParsedSymbolsBeforeError;
}

int RepairItem::getParsedSymbols() const { return ParsedSymbols; }

void RepairItem::setParsedSymbols(int ParsedSymbols) { RepairItem::ParsedSymbols = ParsedSymbols; }

bool RepairItem::isPanicModeUsed() const { return PanicModeUsed; }

void RepairItem::setPanicModeUsed(bool PanicModeUsed) { RepairItem::PanicModeUsed = PanicModeUsed; }

bool RepairItem::isReset() const { return reset; }

void RepairItem::setReset(bool reset) { RepairItem::reset = reset; }
