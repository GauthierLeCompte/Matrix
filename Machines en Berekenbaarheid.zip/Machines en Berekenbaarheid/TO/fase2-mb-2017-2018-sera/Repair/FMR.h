/** \brief The Forward Moving Algorithm shifts the parsing to the next problem
 * by running the LR-parser again on the remaining input.
 */

#ifndef SERA_FMR_H
#define SERA_FMR_H

#include "Rules.h"

class FMR : public Rules
{
public:
        /** \brief constructor
         *
         */
        FMR();

        /** \brief destructor
         *
         */
        virtual ~FMR();

        /** \brief rule that shifts to the next error in the LR-parser if the parser can parse at least 1 input symbol
         * than append to history and return smart pointer of the instance of the possible solution
         *
         * @param item: smart pointer of a possible solution
         * @param parser: reference of the used parser
         * @param debug: true if you want every step of finding the solutions or fals if you are only interested in the solution
         * @return vector of 1 shared pointer of the repairItem instance
         */
        std::vector<std::shared_ptr<RepairItem>> rule(std::shared_ptr<RepairItem> item, LR& parser,
                                                      bool debug) override;
};

#endif // SERA_FMR_H
