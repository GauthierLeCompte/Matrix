#include "InsertRule.h"

InsertRule::InsertRule() {}

InsertRule::~InsertRule() {}

std::vector<std::shared_ptr<RepairItem>> InsertRule::rule(std::shared_ptr<RepairItem> item, LR& parser, bool debug)
{
        std::vector<std::shared_ptr<RepairItem>> allRepairs;
        unsigned int lastStackElement = std::stoi(item->getStack().back());

        // We want to get all insert possibilities for 'lastStackElement' so we find the correct row
        for (unsigned int i = 0; i < parser.getParseTable()->getTable().size(); ++i) {
                // If we have the correct row
                if (lastStackElement == i) {
                        // Loop over all the actions from row i
                        for (unsigned int j = 0; j < parser.getParseTable()->getTable()[i].size(); ++j) {
                                // We want to make sure you only insert terminals
                                bool isTerminal = false;
                                std::string insertValue;
                                for (auto constant : parser.getParseTable()->getTerminals()) {
                                        if (constant == parser.getParseTable()->getSymbols()[j]) {
                                                isTerminal = true;
                                                insertValue = constant;
                                                break;
                                        }
                                }

                                if (isTerminal) {
                                        // If action[j] is not rejecting
                                        if (!parser.getParseTable()->getTable()[i][j]->isRejecting()) {
                                                std::shared_ptr<RepairItem> newItem =
                                                    std::make_shared<RepairItem>(*item);

                                                std::vector<std::string> stack = newItem->getStack();
                                                std::vector<std::shared_ptr<repair::Action>> history =
                                                    newItem->getHistory();
                                                std::vector<std::string> input = {
                                                    parser.getParseTable()->getSymbols()[j]};
                                                // update repaired input
                                                std::vector<std::string> inputItem = item->getInput();
                                                std::vector<std::string> repairedInput = item->getRepairedInput();
                                                int countInp = inputItem.size();
                                                int countRep = repairedInput.size();
                                                int count = countRep - countInp;

                                                repairedInput.insert(repairedInput.begin() + count + 1,
                                                                     parser.getParseTable()->getSymbols()[j]);

                                                input.insert(input.end(), newItem->getInput().begin(),
                                                             newItem->getInput().end());

                                                parser.setRejecting(false);

                                                // We want to keep on executing 'action' untill the symbol is deleted
                                                // from input
                                                // in case of reduce we will reduce first, and then do a shift with
                                                // symbol (while loop will end after shift)
                                                // in case of shift we will only need to exectute once
                                                while (input[0] == parser.getParseTable()->getSymbols()[j] and
                                                       !parser.isRejecting()) {
                                                        int lastTerminal = 0;
                                                        // If last stack element is an index
                                                        if (parser.validStack(stack)) {
                                                                int lastIndex = std::stoi(stack[stack.size() - 1]);
                                                                parser.getParseTable()->getTable()[lastIndex]
                                                                                                  [j]->execute(
                                                                                                      stack, input,
                                                                                                      parser.file,
                                                                                                      debug);
                                                        } else {
                                                                int lastIndex = std::stoi(stack[stack.size() - 2]);
                                                                parser.getParseTable()->getTable()[lastIndex];

                                                                for (unsigned int count = 0;
                                                                     count <
                                                                     parser.getParseTable()->getSymbols().size();
                                                                     ++count) {
                                                                        if (stack.back() ==
                                                                            parser.getParseTable()
                                                                                ->getSymbols()[count]) {
                                                                                lastTerminal = count;
                                                                                break;
                                                                        }
                                                                }
                                                                parser.getParseTable()
                                                                    ->getTable()[lastIndex][lastTerminal]
                                                                    ->execute(stack, input, parser.file, debug);
                                                        }
                                                }

                                                if (!parser.isRejecting()) {

                                                        history.push_back(
                                                            std::make_shared<repair::Insert>(insertValue));

                                                        newItem->setStack(stack);
                                                        newItem->setInput(input);
                                                        newItem->setHistory(history);
                                                        newItem->setRepairedInput(repairedInput);
                                                        newItem->setCost(item->getCost());
                                                        newItem->setInsertsDeletes({item->getInsertsDeletes().first + 1,
                                                                                    item->getInsertsDeletes().second});
                                                        newItem->setParsedSymbolsBeforeError(
                                                            item->getParsedSymbolsBeforeError());
                                                        newItem->setParsedSymbols(item->getParsedSymbols());
                                                        newItem->setPanicModeUsed(item->isPanicModeUsed());
                                                        newItem->setReset(item->isReset());
                                                        allRepairs.push_back(newItem);
                                                }
                                        }
                                }
                        }
                }
        }

        return allRepairs;
}
