#ifndef SERA_REPAIRITEM_H
#define SERA_REPAIRITEM_H

#include "History/Action.h"
#include <iostream>
#include <memory>
#include <vector>

class RepairItem
{
private:
        /*holds remaining stack*/
        std::vector<std::string> stack;
        /*holds remaining input*/
        std::vector<std::string> input;
        /*holds remaining history*/
        std::vector<std::shared_ptr<repair::Action>> history;
        /*holds repaired input*/
        std::vector<std::string> repairedInput;

        std::pair<int, int> InsertsDeletes = {0, 0};

        int ParsedSymbolsBeforeError = 0;

        int ParsedSymbols = 0;

        bool PanicModeUsed = false;

        bool reset = false;

        int cost = 0;

public:
        /**
         * \brief Constructor
         */
        RepairItem() = default;

        /**
         *  \brief Constructor with parameters
         * @param s = remaining stack
         * @param i = remaining input
         * @param h = history of actions
         * @param r = repaired input
         */
        RepairItem(std::vector<std::string> s, std::vector<std::string> i,
                   std::vector<std::shared_ptr<repair::Action>> h, std::vector<std::string> r);

        /**
         * \brief Copy constructor
         * @param that
         */
        RepairItem(const RepairItem& that);

        /**
         * \brief Destructor
         */
        ~RepairItem() = default;

        /**
         * \brief Returns the stack
         * @return vector of strings
         */
        const std::vector<std::string>& getStack() const;

        /**
         * \brief Sets the stack
         * @param stack
         */
        void setStack(const std::vector<std::string>& stack);

        /**
         * \brief Returns the input
         * @return vector of strings
         */
        const std::vector<std::string>& getInput() const;

        /**
         * \brief Sets the input
         */
        void setInput(const std::vector<std::string>& input);

        /**
         * \brief Returns the history
         * @return vector of Actions
         */
        const std::vector<std::shared_ptr<repair::Action>>& getHistory() const;

        /**
         * \brief Sets the history
         * @param history
         */
        void setHistory(const std::vector<std::shared_ptr<repair::Action>>& history);

        /**
         * \brief Returns the repaired input
         * @return vector of strings
         */
        const std::vector<std::string>& getRepairedInput() const;

        /**
         * \brief Sets the repaired input
         * @param repairedInput
         */
        void setRepairedInput(const std::vector<std::string>& repairedInput);

        /**
         * \brief Adds a certain cost to the overall cost
         * @param cost
         */
        void addToCost(int cost);

        /**
         * \brief Sets the cost
         * @param cost
         */
        void setCost(int cost);

        /**
         * \brief Returns the cost
         * @return
         */
        int getCost() const;

        /**
         * \brief Returns the inserts and deletes done
         * @return pair of int
         */
        const std::pair<int, int>& getInsertsDeletes() const;

        /**
         * \brief Sets the inserts and deletes
         * @param InsertsDeletes
         */
        void setInsertsDeletes(const std::pair<int, int>& InsertsDeletes);

        /**
         * \brief Resets the inserst and deletes to 0
         */
        void resetInsertsDeletes();

        /**
         * \brief Returns the amount of symbols parsed before the error was found
         * @return
         */
        int getParsedSymbolsBeforeError() const;

        /**
         * Sets the amount of symbols parsed before the error was found
         * @param ParsedSymbolsBeforeError
         */
        void setParsedSymbolsBeforeError(int ParsedSymbolsBeforeError);

        /**
         * Returns the amount of symbols parsed
         * @return int
         */
        int getParsedSymbols() const;

        /**
         * Sets the amount of symbols parsed
         * @param ParsedSymbols
         */
        void setParsedSymbols(int ParsedSymbols);

        /**
         * Returns is panic mode was used on this repairItem
         * @return bool
         */
        bool isPanicModeUsed() const;

        /**
         * Sets is panic mode was used
         * @param PanicModeUsed
         */
        void setPanicModeUsed(bool PanicModeUsed);

        /**
         * Returns if we can reset the amount of symbols parsed
         * @return
         */
        bool isReset() const;

        /**
         * Sets the reset
         * @param reset
         */
        void setReset(bool reset);
};

#endif // SERA_REPAIRITEM_H
