#include "Rules.h"

Rules::Rules() {}

Rules::~Rules() {}
