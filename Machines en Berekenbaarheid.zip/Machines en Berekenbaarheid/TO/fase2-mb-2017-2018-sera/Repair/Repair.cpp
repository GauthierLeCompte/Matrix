#include "Repair.h"
#include "DeletionRule.h"
#include "FMR.h"
#include "InsertRule.h"
#include "Rules.h"

std::vector<std::string> Repair::RepairRule(std::vector<std::string> i)
{
        /*Uses the LR parser to parse string i and if an error occures  it uses RepairRule2 to fix it*/
        parser.parse(i, false);

        // if input not in cfg
        if (!parser.isRejecting() and !parser.isAccepting()) {
                return {};
        }

        // if rejecting: fix it with repair rule algorithm
        else if (parser.isRejecting()) {
                // get the stack and input of the moment just before the first error
                std::vector<std::vector<std::string>> rejectVar = parser.getRejectingVar();
                std::vector<std::string> stack = rejectVar[0];
                std::vector<std::string> input = rejectVar[1];

                parser.file << "Input: ";
                for (const auto& s : i) {
                        parser.file << s;
                }
                parser.file << " got rejected";

                std::shared_ptr<RepairItem> item = std::make_shared<RepairItem>(RepairItem(stack, input, {}, i));
                item->setParsedSymbolsBeforeError(i.size() - input.size() + 1);
                // use repair rule algorithm to fix the input
                std::vector<std::shared_ptr<RepairItem>> repairedItemVec = RepairRule2({item});

                if (leastCost) {
                        repairedItemVec = sortByLeastCost(repairedItemVec);
                }

                bool MultipleAnswers = false;
                std::vector<std::shared_ptr<RepairItem>> multipleAnsw;
                std::shared_ptr<RepairItem> repairedItem;
                if (repairedItemVec.size() == 0) {
                        std::cerr << "No solution was found" << std::endl;
                        return {};
                } else {
                        if (repairedItemVec.size() > 1) {
                                multipleAnsw.push_back(repairedItemVec[0]);
                                for (unsigned int index = 1; index < repairedItemVec.size(); ++index) {
                                        if (repairedItemVec[index - 1]->getCost() == repairedItemVec[index]->getCost()) {
                                                multipleAnsw.push_back(repairedItemVec[index]);
                                        } else {
                                                break;
                                        }
                                }

                                if (multipleAnsw.size() > 1) {
                                        MultipleAnswers = true;
                                }
                        }

                        repairedItem = repairedItemVec[0];
                }

                // print out repaired input
                if (!MultipleAnswers or !leastCost) {
                        if (repairedItem->isPanicModeUsed()) {
                                parser.file
                                    << "<br><br>Panic mode was used so there may still be an error in the result";

                                parser.file
                                    << "<br>We repaired the input to the (semi-)working string: ";

                        } else {
                                parser.file
                                    << "<br>";

                                parser.file
                                    << "<br>We repaired the input to the working string: ";
                        }
                        for (const auto &s : repairedItem->getRepairedInput()) {
                                parser.file << s;
                        }
                        parser.file << "\n\n";

                        std::vector<std::string> rep = repairedItem->getRepairedInput();
                        parser.setRejecting(false);
                        parser.setAccepting(false);
                        parser.parse(rep, false);
                } else {
                    if (repairedItem->isPanicModeUsed()) {
                        parser.file << "<br><br>Panic mode was used so there may still be an error in the result";
                        parser.file << "<br>Multiple (semi-)correct solutions have been found with the same cost:<br> "<< std::endl;

                    } else {
                        parser.file << "<br>";
                        parser.file << "<br>Multiple correct solutions have been found with the same cost:<br> "<< std::endl;
                    }

                    for(auto sol : multipleAnsw){
                        parser.file << "&emsp;&emsp;" ;
                        for(auto item: sol->getRepairedInput()){
                            parser.file << item;
                        }
                        parser.file << "<br>"<< std::endl;
                    }
                }

        } else {
                // print out used input
                parser.file << "<br><br>When parsing: ";
                for (const auto& s : i) {
                        parser.file << s;
                }
                parser.file << " no errors occured.<br>\n";
        }
        reset();
        parser.reset();
        return {};
}

std::vector<std::shared_ptr<RepairItem>> Repair::RepairRule2(std::vector<std::shared_ptr<RepairItem>> possibleSolutions)
{
        /*Use repair algorithme to send all the possible solutions with breath first algorithm
         * at the right time to deletion, insertion and fmr and pick 1 solution*/
        // bool used to see when the algorithm can stop
        // new vector to keep the solutions of insertion and deletion in
        std::vector<std::shared_ptr<RepairItem>> newSolutions = {};
        std::shared_ptr<Rules> ins = std::make_shared<InsertRule>();
        std::shared_ptr<Rules> del = std::make_shared<DeletionRule>();
        std::shared_ptr<Rules> fmr = std::make_shared<FMR>();
        for (const auto& posSol : possibleSolutions) {
                // If we passed the limit of 10 symbols parsed we reset the limit for the inserts and deletes
                if ((posSol->getParsedSymbols() + posSol->getParsedSymbolsBeforeError()) % 10 == 0 or
                    posSol->isReset()) {
                        if ((posSol->getParsedSymbols() + posSol->getParsedSymbolsBeforeError()) != 0) {
                                posSol->resetInsertsDeletes();
                                posSol->setReset(false);
                        }
                }

                if (posSol->getInsertsDeletes().first < insertionLimit or insertionLimit == -1) {
                        std::vector<std::shared_ptr<RepairItem>> inSol = ins->rule(posSol, parser, debug);
                        if (leastCost) {
                                for (auto rItem : inSol) {
                                        rItem->addToCost(cost->getInsertCost(rItem->getHistory().back()->value()));
                                }
                        }
                        newSolutions.insert(newSolutions.end(), inSol.begin(), inSol.end());
                }
                // If we have no limit on the inserts or haven't reached it yet
                if (posSol->getInsertsDeletes().second < deletionLimit or deletionLimit == -1) {
                        bool DontAdd = false;
                        if (posSol->getInput().size() == 1) {
                                DontAdd = true;
                        }
                        std::shared_ptr<RepairItem> delSol = del->rule(posSol, parser, debug)[0];
                        // Add the cost for the inserts
                        if (leastCost) {
                                delSol->addToCost(cost->getDeleteCost());
                        }

                        bool equal = true;
                        // If we have no limit on the deletes or haven't reached it yet
                        if (delSol.get()->getRepairedInput().size() == posSol.get()->getRepairedInput().size() &&
                            posSol->getHistory().size() != 0) {
                                // Check if the delete is not on of the previous solutions to avoid duplicates
                                for (unsigned int i = 0; i < delSol.get()->getRepairedInput().size(); i++) {
                                        if (delSol.get()->getRepairedInput()[i] !=
                                            posSol.get()->getRepairedInput()[i]) {
                                                equal = false;
                                        }
                                }
                        } else {
                                equal = false;
                        }
                        if (!equal && !DontAdd) {
                                newSolutions.push_back(delSol);
                        }
                }
        }

        // new vector to keep the, modyfied by the formward moving rule, solutions in
        std::vector<std::shared_ptr<RepairItem>> fmrSolutions = {};

        // If there are no new solutions because of the limits -> Panic mode
        if (newSolutions.size() == 0) {
                if (repairs.size() != 0) {
                        return repairs;
                } else {
                        if (panicmode) {
                                // For all the solutions execute panic mode
                                for (const auto& posSol : possibleSolutions) {

                                        // We need the stack to edit
                                        std::vector<std::string> SolStack = posSol->getStack();
                                        std::string inputErrorSymbol = posSol->getInput()[0];
                                        bool OutOfPanic = false;

                                        // Will loop over the whole stack until it may continue or it cannot be repaired
                                        while (!OutOfPanic) {
                                                // If the stack is empty we will remove the input symbol that gave the
                                                // error
                                                if (SolStack.size() == 1) {
                                                        std::vector<std::string> inputSol = posSol->getInput();
                                                        inputSol.erase(inputSol.begin(), inputSol.begin() + 1);
                                                        posSol->setInput(inputSol);
                                                        SolStack = posSol->getStack();
                                                }
                                                // If the input is empty then we can't continue
                                                if (posSol->getInput().size() == 1) {
                                                        break;
                                                }

                                                bool state = false;
                                                unsigned int stateInt = 0;

                                                // Check if the top of the stack is state
                                                for (unsigned int i = 0; i < parser.getParseTable()->getTable().size();
                                                     i++) {
                                                        if (SolStack.back() == std::to_string(i)) {
                                                                stateInt = i;
                                                                state = true;
                                                        }
                                                }

                                                // If it is an accepting state check if the parse table can accept with
                                                // the error symbol
                                                if (state) {
                                                        Action* action =
                                                            parser.getParseTable()->get(stateInt, inputErrorSymbol);
                                                        if (action->str() != "") {
                                                                // If there is an action that accepts it we get out of
                                                                // the loop and continue
                                                                posSol->setStack(SolStack);
                                                                posSol->setPanicModeUsed(true);
                                                                newSolutions.push_back(posSol);
                                                                OutOfPanic = true;
                                                        } else {
                                                                // If not we pop the top of the stack
                                                                SolStack.pop_back();
                                                        }
                                                } else {
                                                        SolStack.pop_back();
                                                }
                                        }
                                }
                        }
                }
        }
        if (newSolutions.size() == 0) {
                return repairs;
        }
        // If for three times the new solutions do not get a lower cost we stop looking for it
        // WARNING Depending on the cost this method might not work to stop so we should always use a limit
        if (leastCost and possibleSolutions[0]->getHistory().size() != 0 and !panicmode and insertionLimit == -1 and
            deletionLimit == -1) {
                int LowOld = getLowestCost(possibleSolutions);
                int LowNew = getLowestCost(newSolutions);

                if (LowNew > LowOld) {
                        leastCostNotLessCount++;
                        if (repairs.size() == 0) {
                                leastCostNotLessCount = 0;
                        }
                        if (leastCostNotLessCount == 3) {
                                return repairs;
                        }
                }
        }

        // By always using al the options the program will slow down so we only use a selection of the possible
        // solutions

        RemoveRepairsPanicModeIfPossible(newSolutions);

        if (leastCost) {
                newSolutions = sortByLeastCost(newSolutions);
                if (newSolutions.size() > 10) {
                        newSolutions.erase(newSolutions.begin() + 10, newSolutions.end());
                }
        }

        for (const auto& newSol : newSolutions) {
                std::shared_ptr<RepairItem> fmrSol = fmr->rule(newSol, parser, debug)[0];

                // if we reached accepting state in the fmr algorithm hen the algortihm stops and acc becomes true
                if (parser.isAccepting()) {
                        repairs.push_back(fmrSol);
                        parser.setAccepting(false);
                        amountRepairs++;
                        if (amountRepairs == limitRepairs && limitRepairs != -1) {
                                return repairs;
                        }
                } else {
                        fmrSolutions.push_back(fmrSol);
                }
        }

        return RepairRule2(fmrSolutions);
}

void Repair::setLimitRepairs(int limitRepairs) { Repair::limitRepairs = limitRepairs; }

void Repair::setLimitsInsDels(int insLim, int delLim)
{
        insertionLimit = insLim;
        deletionLimit = delLim;
}

void Repair::setLeastCost(bool leastCost) { Repair::leastCost = leastCost; }

LR& Repair::getParser() const { return parser; }

std::vector<std::shared_ptr<RepairItem>> Repair::sortByLeastCost(std::vector<std::shared_ptr<RepairItem>> items)
{

        std::sort(items.begin(), items.end(), [](std::shared_ptr<RepairItem> a, std::shared_ptr<RepairItem> b) {
                return a->getCost() < b->getCost();
        });
        return items;
}

int Repair::getLowestCost(std::vector<std::shared_ptr<RepairItem>> vector)
{
        int lowestCost = vector[0]->getCost();

        for (auto item : vector) {
                if (item->getCost() < lowestCost) {
                        lowestCost = item->getCost();
                }
        }

        return lowestCost;
}

int Repair::getSymbolsRegion() const { return SymbolsRegion; }

void Repair::setSymbolsRegion(int SymbolsRegion) { Repair::SymbolsRegion = SymbolsRegion; }

bool Repair::isPanicmode() const { return panicmode; }

void Repair::setPanicmode(bool panicmode) { Repair::panicmode = panicmode; }

std::pair<int, int> Repair::getInsDels(std::shared_ptr<RepairItem> item)
{
        int ins = 0;
        int dels = 0;
        for (auto action : item.get()->getHistory()) {
                if (action->type() == "insert") {
                        ins++;
                }
                if (action->type() == "delete") {
                        dels++;
                }
        }
        return {ins, dels};
}

void Repair::RemoveRepairsPanicModeIfPossible(std::vector<std::shared_ptr<RepairItem>>& vector)
{
        std::vector<std::shared_ptr<RepairItem>> tempvec;
        for (auto repair : vector) {
                if (!repair->isPanicModeUsed()) {
                        tempvec.push_back(repair);
                }
        }
        if (tempvec.size() != 0) {
                vector = tempvec;
        }
}

void Repair::reset()
{
        amountRepairs = 0;
        leastCostNotLessCount = 0;
        repairs.clear();
}
