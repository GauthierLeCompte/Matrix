#include "DeletionRule.h"

DeletionRule::DeletionRule() {}

DeletionRule::~DeletionRule() {}

std::vector<std::shared_ptr<RepairItem>> DeletionRule::rule(std::shared_ptr<RepairItem> item, LR& parser, bool debug)
{
        // Only delete item if remaining input > 1
        if (item->getInput().size() > 1) {
                std::vector<std::shared_ptr<repair::Action>> history = item->getHistory();
                std::vector<std::string> input = item->getInput();

                // update repaired input
                std::vector<std::string> repairedInput = item->getRepairedInput();
                int countInp = input.size();
                int countRep = repairedInput.size();
                int count = countRep - countInp;

                std::string deleteValue = input.front();
                history.push_back(std::make_shared<repair::Delete>(deleteValue));

                // both + 1 because in the input string the $ symbol is pushed in the repaired not
                repairedInput.erase(repairedInput.begin() + count + 1, repairedInput.begin() + count + 2);
                input.erase(input.begin(), input.begin() + 1);

                std::shared_ptr<RepairItem> newItem = std::make_shared<RepairItem>(*item);
                newItem->setInput(input);
                newItem->setHistory(history);
                newItem->setRepairedInput(repairedInput);
                newItem->setCost(item->getCost());
                newItem->setInsertsDeletes({item->getInsertsDeletes().first, item->getInsertsDeletes().second + 1});
                newItem->setParsedSymbolsBeforeError(item->getParsedSymbolsBeforeError());
                newItem->setParsedSymbols(item->getParsedSymbols());
                newItem->setPanicModeUsed(item->isPanicModeUsed());
                newItem->setReset(item->isReset());
                return {newItem};
        }

        return {item};
}

