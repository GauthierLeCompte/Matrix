#ifndef SERA_REPAIRACTION_H
#define SERA_REPAIRACTION_H

#include <string>

namespace repair {
class Action
{
public:
        /**
         * returns type of action
         * @return action as string
         */
        virtual const std::string type() const = 0;

        /**
         * returns value from action
         * @return value as string
         */
        virtual const std::string value() const = 0;
};

class Insert : public Action
{
private:
        const std::string val;

public:
        /**
         * Insert item
         * @param v value
         */
        explicit Insert(const std::string v) : val(v){};

        /**
         * returns type of action
         * @return action as string (insert)
         */
        const std::string type() const override { return "insert"; };

        /**
         * returns value from action
         * @return value as string
         */
        const std::string value() const override { return val; };
};

class Delete : public Action
{
private:
        const std::string val;

public:
        /**
         * delete item
         * @param v value
         */
        explicit Delete(const std::string v) : val(v){};

        /**
         * returns type of action
         * @return action as string (delete)
         */
        const std::string type() const override { return "delete"; };

        /**
         * returns value from action
         * @return value as string
         */
        const std::string value() const override { return val; };
};

class Shift : public Action
{
public:
        /**
         * Constructor
         */
        Shift() = default;

        /**
         * returns type of action
         * @return action as string (shift)
         */
        const std::string type() const override { return "shift"; };

        /**
         * returns value from action
         * @return value as string
         */
        const std::string value() const override { return ""; };
};
}

#endif // SERA_ACTION_H
