#ifndef SERA_DELETIONRULE_H
#define SERA_DELETIONRULE_H

#include "Rules.h"

class DeletionRule : public Rules
{
public:
        /**
         * Constructor for deletion rule
         */
        DeletionRule();

        /**
         * Destructor for deletion rule
         */
        ~DeletionRule() override;

        /**
         * Deletion rule
         * @param item Item from which we want to delete
         * @param parser LR Parser
         * @param debug Extended output or not
         * @return Repaired Item object
         */
        std::vector<std::shared_ptr<RepairItem>> rule(std::shared_ptr<RepairItem> item, LR& parser,
                                                      bool debug) override;
};

#endif // SERA_DELETIONRULE_H
