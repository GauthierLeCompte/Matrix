#include "LR/Parser/LR.h"
#include "Repair/Cost.h"
#include "Repair/Repair.h"
#include <iostream>
int main()
{
        CFG C1("../input/CFG6.json");
        std::ofstream f("../Output/output.html");
        LR* l1 = new LR(C1, f);
        l1->getParseTable()->toHTML("../Output/table.html");
        Cost c("../input/Cost.json");

        Repair repair("../input/Cost.json", *l1, true);
        repair.setLeastCost(true);
        repair.setPanicmode(true);
        repair.setLimitRepairs(-1);
        repair.setLimitsInsDels(4, 3);

        std::vector<std::string> repaired_input = repair.RepairRule({"n","n","n","n","n","n","n","n","n","n"});

}
