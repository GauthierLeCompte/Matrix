#include "../LR/Parser/LR.h"
#include "../Repair/Cost.h"
#include "../Repair/Repair.h"
#include <iostream>

int main() 
{
		// CFG input
	    CFG C("../input/CFG1.json");

	    // Main output
        std::ofstream f("../demo/Output/demo1.html");

        // Create LR parser with CFG & output stream
        LR l = LR(C, f);

        // Write parse table to html.
        l.getParseTable()->toHTML("../demo/Output/demo_table1.html");

        // cost source file, LR parser, debug boolean
        Repair repair("../input/Cost.json", l, false);

        // Set parameters
        repair.setLeastCost(false);
        repair.setLimitRepairs(-1);
        repair.setLimitsInsDels(4, 3);

        // Choose the string
        std::vector<std::string> repaired_input = repair.RepairRule({"d"});
}