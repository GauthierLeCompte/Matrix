//
// Created by senne on 1/29/19.
//

#include "../LR/Parser/LR.h"
#include "../Repair/Cost.h"
#include "../Repair/Repair.h"
#include <iostream>

int main()
{
    // CFG input
    CFG C("../input/CFG6.json");

    // Main output
    std::ofstream f("../demo/Output/demo5.html");

    // Create LR parser with CFG & output stream
    LR l = LR(C, f);

    // Write parse table to html.
    l.getParseTable()->toHTML("../demo/Output/demo_table5.html");

    // cost source file, LR parser, debug boolean
    Repair repair("../input/Cost.json", l, false);

    // Set parameters
    repair.setLeastCost(true);
    repair.setLimitRepairs(-1);
    repair.setLimitsInsDels(4, 3);

    // Choose the string
    std::vector<std::string> repaired_input = repair.RepairRule({"*","+","+","(","+","*","(","+","*"});
}