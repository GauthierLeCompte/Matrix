//
// Created by tmtoon on 27.11.18.
//

#ifndef SERA_USEFULFUNCTIONS_H
#define SERA_USEFULFUNCTIONS_H

#include <vector>
#include <algorithm>

template <typename T>
const bool find(const std::vector<T>& vector, const T& item) {
    return (std::find(vector.begin(), vector.end(), item) != vector.end());
}

template <typename T>
const bool find(const std::set<T>& set, const T& item) {
    return (not set.count(item) == 0);
}

#endif //SERA_USEFULFUNCTIONS_H
