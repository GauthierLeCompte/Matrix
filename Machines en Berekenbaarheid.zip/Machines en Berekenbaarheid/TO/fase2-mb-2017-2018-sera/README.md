Onze Syntax Error Repairer Algoritme zorgt ervoor dat strings die niet geaccepteerd worden door de parser, aangepast worden (naar de meest logische string) zodat deze uiteindelijk wel in een accepting state terecht komen. 

Bij ons programma kan men ook een limiet zetten op het aantal repairs dat je wilt. Als je bijvoorbeeld 5 als parameter geeft, krijg je 5 repairs terug. Als je -1 als parameter geeft gaat hij alle mogelijke repairs teruggeven.

Men kan ook een cost meegeven voor een delete en insert. De cost wordt meegeven via een json bestand genaamd cost.json in de input map. Bij de delete is de cost altijd even groot, bijvoorbeeld 2. Bij de insert kan je voor elk symbool apart een aparte cost meegeven. Bijvoorbeeld een “n” heeft een cost van 3 terwijl een “*” een cost heeft van 2. Dit houdt dus ook wel in telkens er andere symbolen gebruikt worden, we de cost.json file moeten aanpassen. Als er meerdere oplossingen met dezelfde cost zijn gaat hij al deze oplossingen geven, tenzij we een limiet van bijvoorbeeld 3 hebben gegeven, dan gaat hij weer de eerste 3 geven.

Als je panic mode op false zet, dan gebruik je het panic mode algoritme niet. Dit betekent dan dat er bij meer gevallen geen/minder oplossingen gevonden kan worden. 

Set limits ins deletes (4,3) wilt zeggen dat als je geen 10 symbolen kunt parsen met minder dan 4 inserts en 3 deletes, panic mode opgeroepen wordt.

Als je het programma runt, kan je in de output map 2 html files zien. Een ervan is de parse table en de andere is de html file met 1 of meerdere oplossingen. De html file van de oplossingen kan ofterwijl gewoon de oplossingen bevatten van de gecorrigeerde string als je debug op false hebt gezet, of een uitgebreide/debug oplossing die alle tussenstappen toont als je debug op true zet. Deze parameter kan aangepast worden in de constructor van de repair klasse die aangemaakt wordt in de main.

