#include "Production.h"

const std::string& Production::getHead() const { return Head; }

void Production::setHead(const std::string& Head) { Production::Head = Head; }

const std::vector<std::string>& Production::getBody() const { return Body; }

void Production::setBody(const std::vector<std::string>& Body) { Production::Body = Body; }

Production::Production(const std::string& h, const std::vector<std::string>& b) : Body(b), Head(h) {}
