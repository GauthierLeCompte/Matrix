#include "CFG.h"
#include "../single_include/nlohmann/json.hpp"
#include <fstream>

using json = nlohmann::json;

CFG::CFG(std::string file) { Parse(file); }

void CFG::Parse(std::string file)
{
        std::ifstream ifstr(file);
        json js = json::parse(ifstr);

        std::string StartS = js["Start"];
        std::vector<std::string> Variables = js["Variables"];
        std::vector<std::string> Terminals = js["Terminals"];
        json::array_t Productions = js["Productions"];
        std::vector<Production*> productions;

        for (auto Item : Productions) {
                Production* ProdToIns = new Production();
                ProdToIns->setHead(Item["head"]);
                ProdToIns->setBody(Item["body"]);
                if (ProdToIns->getBody().size() == 0) {
                        ProdToIns->setBody({""});
                }
                productions.push_back(ProdToIns);
        }

        this->setProductions(productions);
        this->setStartState(StartS);
        this->setTerminals(Terminals);
        this->setVariables(Variables);
}

const std::vector<std::string>& CFG::getVariables() const { return Variables; }

void CFG::setVariables(const std::vector<std::string>& Variables) { CFG::Variables = Variables; }

const std::vector<std::string>& CFG::getTerminals() const { return Terminals; }

void CFG::setTerminals(const std::vector<std::string>& Terminals) { CFG::Terminals = Terminals; }

const std::string& CFG::getStartState() const { return StartState; }

void CFG::setStartState(const std::string& StartState) { CFG::StartState = StartState; }

const std::vector<Production*>& CFG::getProductions() const { return Productions; }

void CFG::setProductions(const std::vector<Production*>& Productions) { CFG::Productions = Productions; }

void CFG::addProduction(Production* p) { Productions.push_back(p); }

void CFG::addTerminal(const std::string& t) { Terminals.push_back(t); }

void CFG::addVariable(const std::string& v) { Variables.push_back(v); }
