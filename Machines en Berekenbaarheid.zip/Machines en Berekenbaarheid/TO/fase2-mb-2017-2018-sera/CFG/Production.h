#ifndef LL_1_PRODUCTION_H
#define LL_1_PRODUCTION_H

#include <iostream>
#include <vector>

class Production
{
private:
        std::vector<std::string> Body;
        std::string Head;

public:
        Production(const std::string& h, const std::vector<std::string>& b);

        Production() = default;

        const std::string& getHead() const;

        void setHead(const std::string& Head);

        const std::vector<std::string>& getBody() const;

        void setBody(const std::vector<std::string>& Body);
};

#endif // LL_1_PRODUCTION_H
