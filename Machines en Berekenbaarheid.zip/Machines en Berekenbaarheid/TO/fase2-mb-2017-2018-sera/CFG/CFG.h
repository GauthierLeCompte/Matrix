#ifndef LL_1_CFG_H
#define LL_1_CFG_H

#include "Production.h"
#include <iostream>
#include <string>
#include <vector>

class CFG
{
private:
        std::vector<std::string> Variables;
        std::vector<std::string> Terminals;
        std::string StartState;
        std::vector<Production*> Productions;

public:
        CFG(std::string file);
        void Parse(std::string file);

        const std::vector<std::string>& getVariables() const;

        void setVariables(const std::vector<std::string>& Variables);

        const std::vector<std::string>& getTerminals() const;

        void setTerminals(const std::vector<std::string>& Terminals);

        const std::string& getStartState() const;

        void setStartState(const std::string& StartState);

        const std::vector<Production*>& getProductions() const;

        void setProductions(const std::vector<Production*>& Productions);

        void addProduction(Production* p);

        void addTerminal(const std::string& t);

        void addVariable(const std::string& v);
};

#endif // LL_1_CFG_H
