#ifndef LR_ACCEPT_H
#define LR_ACCEPT_H

#include "../Action.h"

class Accept : public Action
{
public:
        /**
         * Constructor for accept class
         */
        Accept();

        /**
         * Returns string if we reach an accepting
         * @return string from action (accepting)
         */
        const std::string str() const override;

        /**
         * Pure virtual function which executes the 'action'
         * @param stack Remaining input
         * @param input Remaining input
         * @param file File to write to
         * @param debug Bool which gives a debug option if opted for
         */
        void execute(std::vector<std::string>& stack, std::vector<std::string>& input, std::ofstream& file,
                     bool debug) override;

        /**
         * Checks if this action is rejecting
         * @return true or false
         */
        bool isRejecting() override;

        /**
         * Checks if this action is accepting
         * @return true or false
         */
        bool isAccepting() override;
};

#endif // LR_ACCEPT_H
