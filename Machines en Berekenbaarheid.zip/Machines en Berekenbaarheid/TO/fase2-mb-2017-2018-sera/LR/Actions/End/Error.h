#ifndef LR_ERROR_H
#define LR_ERROR_H

#include "../Action.h"
#include <iostream>

class Error : public Action
{
public:
        /**
         * Constructor for error class
         */
        Error();

        /**
         * Returns string if we reach an error
         * @return string from action (error)
         */
        const std::string str() const override;

        /**
         * Pure virtual function which executes the 'action'
         * @param stack Remaining input
         * @param input Remaining input
         * @param file File to write to
         * @param debug Bool which gives a debug option if opted for
         */
        void execute(std::vector<std::string>& stack, std::vector<std::string>& input, std::ofstream& file,
                     bool debug) override;

        /**
         * Checks if this action is rejecting
         * @return true or false
         */
        bool isRejecting() override;

        /**
         * Checks if this action is accepting
         * @return true or false
         */
        bool isAccepting() override;
};

#endif // LR_ERROR_H
