#include "Error.h"

Error::Error() {}

void Error::execute(std::vector<std::string>& stack, std::vector<std::string>& input, std::ofstream& file, bool debug)
{
        if (debug)
                file << "Error";
}

const std::string Error::str() const { return ""; }

bool Error::isRejecting() { return true; }

bool Error::isAccepting() { return false; }
