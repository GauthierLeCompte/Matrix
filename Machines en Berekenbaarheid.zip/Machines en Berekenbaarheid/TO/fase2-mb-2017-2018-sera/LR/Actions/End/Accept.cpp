#include "Accept.h"

Accept::Accept() {}

void Accept::execute(std::vector<std::string>& stack, std::vector<std::string>& input, std::ofstream& file, bool debug)
{
        if (debug)
                file << "Accept";
}

const std::string Accept::str() const { return "Accept"; }

bool Accept::isRejecting() { return false; }

bool Accept::isAccepting() { return true; }
