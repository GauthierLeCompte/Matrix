#ifndef LR_REDUCE_H
#define LR_REDUCE_H

#include "../Action.h"
#include <iostream>
#include <vector>

class Reduce : public Action
{
private:
        std::vector<std::string> oldSymbols;

        std::string newSymbols;

        bool wrongStack = false;

public:
        /**
         * Construcot for reduce class
         */
        Reduce();

        /**
         * Construcot for reduce class
         * @param oldSym the symbols we want to replace
         * @param newSym the new symbol
         */
        Reduce(const std::vector<std::string>& oldSym, const std::string& newSym);

        /**
         * Returns string which we want to reduce
         * @return string from action
         */
        const std::string str() const override;

        /**
         * Pure virtual function which executes the 'action'
         * @param stack Remaining input
         * @param input Remaining input
         * @param file File to write to
         * @param debug Bool which gives a debug option if opted for
         */
        void execute(std::vector<std::string>& stack, std::vector<std::string>& input, std::ofstream& file,
                     bool debug) override;

        /**
         * Get the old symbols
         * @return the to be replaced symbols
         */
        const std::vector<std::string>& getOldSymbols() const;

        /**
         * Set new old symbols
         * @param oldSymbols the new old symbols
         */
        void setOldSymbols(const std::vector<std::string>& oldSymbols);

        /**
         * Get the old symbols
         * @return The old symbols
         */
        const std::string& getNewSymbols() const;

        /**
         * Set the new symbols
         * @param newSymbols the new symbols
         */
        void setNewSymbols(const std::string& newSymbols);

        /**
         * Checks if this action is rejecting
         * @return true or false
         */
        bool isRejecting() override;

        /**
         * Checks if this action is accepting
         * @return true or false
         */
        bool isAccepting() override;

        /**
         * Checks if a stack is not valid
         * @return true or false
         */
        bool isWrongStack() const;

        /**
         * Set if a stack is valid or not
         * @param wrongStack true or false
         */
        void setWrongStack(bool wrongStack);
};

#endif // LR_REDUCE_H
