#include "Reduce.h"
#include <sstream>

Reduce::Reduce() {}

Reduce::Reduce(const std::vector<std::string>& oldSym, const std::string& newSym)
    : oldSymbols(oldSym), newSymbols(newSym)
{
}

const std::vector<std::string>& Reduce::getOldSymbols() const { return oldSymbols; }

void Reduce::setOldSymbols(const std::vector<std::string>& oldSymbols) { Reduce::oldSymbols = oldSymbols; }

const std::string& Reduce::getNewSymbols() const { return newSymbols; }

void Reduce::setNewSymbols(const std::string& newSymbols) { Reduce::newSymbols = newSymbols; }

void Reduce::execute(std::vector<std::string>& stack, std::vector<std::string>& input, std::ofstream& file, bool debug)
{
        int count = this->getOldSymbols().size() - 1;
        stack.pop_back();

        std::string backupString = "";
        std::vector<std::string> backupStack = stack;

        while (stack.size() > 1) {
                if (count >= 0) {
                        if (stack.back() != this->getOldSymbols()[count]) {
                                stack = backupStack;
                                this->setWrongStack(true);
                                break;
                        } else {
                                stack.pop_back();
                                backupString = stack.back();
                                stack.pop_back();
                                count--;
                        }
                } else {
                        break;
                }
        }

        if (count >= 0) {
                stack = backupStack;
                this->setWrongStack(true);
                return;
        }

        stack.push_back(backupString);
        stack.push_back(this->getNewSymbols());
}

const std::string Reduce::str() const
{
        std::stringstream s;
        s << newSymbols;
        s << " &rarr; ";
        for (const auto& symb : oldSymbols) {
                s << symb;
        }
        return s.str();
}

bool Reduce::isRejecting()
{
        if (this->isWrongStack()) {
                return true;
        }
        return false;
}

bool Reduce::isAccepting() { return false; }

bool Reduce::isWrongStack() const { return wrongStack; }

void Reduce::setWrongStack(bool wrongStack) { Reduce::wrongStack = wrongStack; }
