#ifndef LR_STATE_H
#define LR_STATE_H

#include "../Action.h"
#include <iostream>
#include <vector>

class Goto : public Action
{
public:
        /**
         * Constructor for goto class
         */
        Goto();

        /**
         * Constructor for goto class
         * @param state string state
         */
        Goto(std::string state);

        /**
         * Constructor for goto class
         * @param state unsigned int state
         */
        Goto(unsigned int state);

        /**
         * Returns string to which state we want to go to
         * @return string from action (goto 8)
         */
        const std::string str() const override;

        /**
         * Pure virtual function which executes the 'action'
         * @param stack Remaining input
         * @param input Remaining input
         * @param file File to write to
         * @param debug Bool which gives a debug option if opted for
         */
        void execute(std::vector<std::string>& stack, std::vector<std::string>& input, std::ofstream& file,
                     bool debug) override;

        /**
         * Returns state from this class
         * @return the state
         */
        const std::string getState() const;

        /**
         * Set state for this class
         * @param state the state
         */
        void setState(const std::string& state);

        /**
         * Checks if this action is rejecting
         * @return true or false
         */
        bool isRejecting() override;

        /**
         * Checks if this action is accepting
         * @return true or false
         */
        bool isAccepting() override;

        /**
         * State as integer
         */
        unsigned int state;
};

#endif // LR_STATE_H
