#include "Goto.h"

Goto::Goto() {}

Goto::Goto(std::string state) { Goto::state = std::stoi(state); }

void Goto::execute(std::vector<std::string>& stack, std::vector<std::string>& input, std::ofstream& file, bool debug)
{
        stack.push_back(this->getState());
}

const std::string Goto::getState() const { return std::to_string(state); }

void Goto::setState(const std::string& state) { Goto::state = std::stoi(state); }

const std::string Goto::str() const { return "goto " + std::to_string(state); }

bool Goto::isRejecting() { return false; }

bool Goto::isAccepting() { return false; }

Goto::Goto(unsigned int state) : state(state) {}

std::ostream& operator<<(std::ostream& os, const Goto* rhs)
{
        os << rhs->state;
        return os;
}
