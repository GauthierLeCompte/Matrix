#include "Shift.h"

Shift::Shift() {}

Shift::Shift(std::string state) { Shift::state = std::stoi(state); }

const std::string Shift::getState() const { return std::to_string(state); }

void Shift::setState(const std::string& state) { Shift::state = std::stoi(state); }

void Shift::execute(std::vector<std::string>& stack, std::vector<std::string>& input, std::ofstream& file, bool debug)
{
        stack.push_back(input[0]);
        stack.push_back(this->getState());

        input.erase(input.begin(), input.begin() + 1);
}

bool Shift::isRejecting() { return false; }

bool Shift::isAccepting() { return false; }

const std::string Shift::str() const { return "shift " + std::to_string(state); }

Shift::Shift(unsigned int state) : state(state) {}

Shift::~Shift() {

}
