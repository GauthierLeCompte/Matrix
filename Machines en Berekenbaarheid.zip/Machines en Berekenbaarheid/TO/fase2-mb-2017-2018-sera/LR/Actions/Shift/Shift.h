#ifndef LR_SHIFT_H
#define LR_SHIFT_H

#include "../Action.h"
#include <iostream>
#include <vector>

class Shift : public Action
{
private:
        unsigned int state;

public:
        /**
         * Constructor for shift class
         */
        Shift();

        /**
         * virtual destructor
         */
        virtual ~Shift();

        /**
         * Constructor for shift class
         * @param state state we want to shift as string
         */
        Shift(std::string state);

        /**
         * Constructor for shift class
         * @param state state we want to shift as unsigned integer
         */
        Shift(unsigned int state);

        /**
         * Returns string which we want to reduce
         * @return string from action
         */
        const std::string str() const override;

        /**
         * Pure virtual function which executes the 'action'
         * @param stack Remaining input
         * @param input Remaining input
         * @param file File to write to
         * @param debug Bool which gives a debug option if opted for
         */
        void execute(std::vector<std::string>& stack, std::vector<std::string>& input, std::ofstream& file,
                     bool debug) override;

        /**
         * Returns state
         * @return the state
         */
        const std::string getState() const;

        /**
         * Sets a state
         * @param state the state
         */
        void setState(const std::string& state);

        /**
         * Checks if this action is rejecting
         * @return true or false
         */
        bool isRejecting() override;

        /**
         * Checks if this action is accepting
         * @return true or false
         */
        bool isAccepting() override;
};

#endif // LR_SHIFT_H
