#ifndef LR_ACTION_H
#define LR_ACTION_H

#include <fstream>
#include <iostream>
#include <vector>

class Action
{
public:
        /**
         * Default constructor for action
         */
        Action() = default;

        /**
         * Destructor for action class
         */
        virtual ~Action();

        /**
         * Checks if action is rejecting
         * @return true or false
         */
        virtual bool isRejecting() = 0;

        /**
         * Checks if action is accepting
         * @return true or false
         */
        virtual bool isAccepting() = 0;

        /**
         * Pure virtual function which executes the 'action'
         * @param stack Remaining input
         * @param input Remaining input
         * @param file File to write to
         * @param debug Bool which gives a debug option if opted for
         */
        virtual void execute(std::vector<std::string>& stack, std::vector<std::string>& input, std::ofstream& file,
                             bool debug) = 0;

        /**
         * Returns string from a certain action
         * @return string from action
         */
        virtual const std::string str() const = 0;
};

#endif // LR_ACTION_H
