/** \brief An item used in LR(1) parse table generation, exists of lhs -> rhs, lookahead and a marker.
 *
 */

#ifndef SERA_LRITEM_H
#define SERA_LRITEM_H

#include <set>
#include <string>
#include <vector>

class LrItem
{
private:
        std::vector<std::string> rhs;
        std::string lhs;
        std::set<std::string> lookahead;
        unsigned int marker;

public:
        /** \brief constructor
         *
         * @param lhs Left side of the production
         * @param rhs Right side of the production
         * @param follow Lookahead symbols
         * @param marker The position of the marker in lhs
         */
        LrItem(const std::string& lhs, const std::vector<std::string>& rhs, const std::set<std::string>& follow,
               unsigned int marker = 0);

        /** \brief returns a string of the item
         *
         * @return string of the item
         */
        const std::string str() const;

        /** \brief attempts to move the marker 1 to the right, returns bool succes
         *
         * @return succes boolean
         */
        bool moveMarker();

        /** \brief returns current marked symbol
         *
         * @return marked symbol
         */
        const std::string& getMarked() const;

        /** \brief returns the items starting with the symbol after the marked symbol and ending with the lookahead
         * symbols, 1 vector per lookahead symbol
         *
         * @return vector<vector<string>> the string used to calculate lookahead symbols
         */
        const std::vector<std::vector<std::string>> getNextFirst() const;

        /** \brief test for weak equality: excluding the lookahead symbols
         *
         * @param rhs item to compare against
         * @return bool if they are equal excluding the lookahead symbols
         */
        const bool weakEq(const LrItem& rhs) const;

        /** \brief returns lookahead
         *
         * @return lookahead
         */
        const std::set<std::string>& getLookahead() const;

        /** \brief adds a lookahead
         *
         * @param la lookahead to add
         */
        void addLookahead(const std::set<std::string>& la);

        /** \brief returns lhs
         *
         * @return lhs
         */
        const std::string& getLhs() const;

        /** \brief return rhs
         *
         * @return rhs
         */
        const std::vector<std::string>& getRhs() const;

        /** \brief compares two LrItems (<)
         *
         * @param lhs left item
         * @param rhs right item
         * @return lhs < rhs
         */
        friend bool operator<(const LrItem& lhs, const LrItem& rhs);

        /** \brief compares two LrItems (>)
         *
         * @param lhs left item
         * @param rhs right item
         * @return lhs > rhs
         */
        friend bool operator>(const LrItem& lhs, const LrItem& rhs);

        /** \brief compares two LrItems (==)
         *
         * @param lhs left item
         * @param rhs right item
         * @return lhs == rhs
         */
        friend bool operator==(const LrItem& lhs, const LrItem& rhs);

        /** \brief compares two LrItems (!=)
         *
         * @param lhs left item
         * @param rhs right item
         * @return lhs != rhs
         */
        friend bool operator!=(const LrItem& lhs, const LrItem& rhs);
};

#endif // SERA_LRITEM_H
