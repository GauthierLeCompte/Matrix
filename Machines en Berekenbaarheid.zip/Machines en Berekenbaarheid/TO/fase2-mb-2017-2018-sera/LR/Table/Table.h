#ifndef LR_TABLE_H
#define LR_TABLE_H

#include <iostream>
#include <set>
#include <vector>

#include "../../CFG/CFG.h"
#include "../Actions/Action.h"
#include "LrItem.h"
#include "State.h"

class Table
{
private:
        std::vector<std::vector<Action*>> table;

        std::vector<std::string> terminals;

        std::vector<std::string> symbols;

        const CFG& c;

        std::set<std::string> GetFirst(std::vector<std::string> prodBody);

        std::set<std::string> GetFirst(std::vector<std::string> prodBody, std::set<std::string> firsts);

        std::vector<std::string> GetFollow(const std::string& Variable, std::set<std::string>& Visited);

        std::vector<Production*> GetProductionsFromVariable(std::string input);

        std::vector<LrItem> Closure(const LrItem&);

        std::vector<LrItem> Closure(const LrItem& i, std::set<LrItem>& set, std::set<LrItem>& visited);

        std::vector<State> generateStates(const State* s);

        std::vector<State> generateStates(const State* s, std::set<const State*>& set, std::vector<LrItem>& visited,
                                          std::vector<std::pair<std::set<LrItem>, unsigned int>>& links);

        void simplifySet(std::set<LrItem>& set);

        void set(unsigned int state, const std::string& terminal, Action* value);

        void createTable(const std::vector<State>& states);

public:
        /** \brief return the action on state id state and string terminal
         *
         * @param state the id
         * @param terminal the string
         * @return Action*
         */
        Action* get(unsigned int state, const std::string& terminal);

        /** \brief constructor
         *
         * @param c CFG to generate table of
         */
        explicit Table(CFG& c);

        /** \btief returns matrix of Action*
         *
         * @return vector<vector<Action*>>
         */
        const std::vector<std::vector<Action*>>& getTable() const;

        /** \brief set Matrix of actions
         *
         * @param table vector<vector<Action*>>
         */
        void setTable(const std::vector<std::vector<Action*>>& table);

        /** \brief returns all symbols
         *
         * @return vector<string>
         */
        const std::vector<std::string>& getSymbols() const;

        /** \brief sets the symbols
         *
         * @param symbol vector<string>
         */
        void setSymbols(const std::vector<std::string>& symbol);

        /** \brief writes to HTML file
         *
         * @param filename output filename
         */
        void toHTML(const std::string& filename);

        /** \brief returns list of terminals
         *
         * @return vector<string>
         */
        const std::vector<std::string>& getTerminals() const;
};

#endif // LR_TABLE_H
