#include "State.h"
#include "../../single_include/tmtoon/usefulFunctions.hpp"

State::State(const std::vector<LrItem>& item, const unsigned int id) : item(item), id(id) {}

const std::string State::str() const
{
        std::string s;
        s += "State ";
        s += std::to_string(id);
        s += " { \n";
        for (unsigned int i = 0; i < item.size(); ++i) {
                s += "    " + item[i].str() + "\n";
        }
        s += "}\n";
        for (const auto& p : links) {
                s += p.first + " -> " + std::to_string(p.second) + "\n";
        }
        return s;
}

const std::vector<LrItem> State::getItems() const { return item; }

bool operator<(const State& lhs, const State& rhs) { return lhs.id < rhs.id; }

bool operator==(const State& lhs, const State& rhs) { return lhs.id == rhs.id; }

bool operator>(const State& lhs, const State& rhs) { return lhs.id > rhs.id; }

const std::vector<std::pair<std::string, unsigned int>> State::getLinks() const { return links; }

void State::addLink(const std::string& s, const unsigned int i) const
{
        for (const auto& l : links) {
                if (l.first == s and l.second == i) {
                        return;
                }
        }
        links.emplace_back(s, i);
}
