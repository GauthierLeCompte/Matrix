#include "LrItem.h"

LrItem::LrItem(const std::string& lhs, const std::vector<std::string>& rhs, const std::set<std::string>& first,
               const unsigned int marker)
    : rhs(rhs), lhs(lhs), lookahead(first), marker(marker)
{
}

const std::string LrItem::str() const
{
        // returns a string of the type: "lhs -> rhs|la/la/la/..." with a dot indicating the marker in rhs.
        std::string L;
        L += lhs;
        L += " -> ";
        for (unsigned int i = 0; i < rhs.size(); ++i) {
                if (i == marker) {
                        L += ".";
                }
                L += rhs[i];
        }
        if (marker == rhs.size()) {
                L += ".";
        }
        L += "|";
        unsigned int i = 0;
        for (const auto& s : lookahead) {
                L += s;
                ++i;
                if (i != lookahead.size()) {
                        L += "/";
                }
        }
        return L;
}

bool operator<(const LrItem& lhs, const LrItem& rhs) { return (lhs.str() < rhs.str()); }

bool operator>(const LrItem& lhs, const LrItem& rhs) { return (lhs.str() > rhs.str()); }

bool operator==(const LrItem& lhs, const LrItem& rhs)
{
        return ((lhs.lhs == rhs.lhs) and (lhs.rhs == rhs.rhs) and (lhs.lookahead == rhs.lookahead) and
                (rhs.marker == lhs.marker));
}

bool LrItem::moveMarker()
{
        // if the marked item is the end of string, don't move the marker.
        if (getMarked() == "$") {
                return false;
        }
        ++marker;

        // if the marker is larger than the amount of elements, the marker is invalid
        return rhs.size() >= marker;
}

const std::string& LrItem::getMarked() const
{
        if (marker < rhs.size()) {
                return rhs[marker];
        } else
                // returns an empty string
                return *new std::string();
}

const std::vector<std::vector<std::string>> LrItem::getNextFirst() const
{
        std::vector<std::vector<std::string>> rval;
        for (const auto& v : lookahead) {
                std::vector<std::string> inner;
                if (marker < rhs.size() - 1) {
                        inner = std::vector<std::string>(rhs.begin() + marker + 1, rhs.end());
                }
                inner.push_back(v);
                rval.push_back(inner);
        }
        return rval;
}

const bool LrItem::weakEq(const LrItem& rhs) const
{
        return (lhs == rhs.lhs and this->rhs == rhs.rhs and marker == rhs.marker);
}

bool operator!=(const LrItem& lhs, const LrItem& rhs) { return (not(lhs == rhs)); }

const std::set<std::string>& LrItem::getLookahead() const { return lookahead; }

void LrItem::addLookahead(const std::set<std::string>& la) { lookahead.insert(la.begin(), la.end()); }

const std::string& LrItem::getLhs() const { return lhs; }

const std::vector<std::string>& LrItem::getRhs() const { return rhs; }
