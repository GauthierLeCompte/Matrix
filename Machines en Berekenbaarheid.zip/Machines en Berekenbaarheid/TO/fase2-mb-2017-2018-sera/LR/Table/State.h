#ifndef SERA_STATE_H
#define SERA_STATE_H

#include "LrItem.h"
#include <vector>

class State
{
private:
        std::vector<LrItem> item;
        mutable std::vector<std::pair<std::string, unsigned int>> links; // doesn't actually affect the object
        unsigned int id;

public:
        /** \brief Constructor for the state
         *
         * @param item the state items
         * @param id the id of the state
         */
        State(const std::vector<LrItem>& item, unsigned int id);

        /** \brief returns a string of the state
         *
         * needed for comparison and printing
         * @return State n {\n Lritem1 \n Lritem2 \n ... \n } Links
         */
        const std::string str() const;

        /** \brief returns the vector of LrItems
         *
         * @return vector of LrItems
         */
        const std::vector<LrItem> getItems() const;

        /** \brief Returns the links
         *
         * string -> state id
         * @return string -> state id
         */
        const std::vector<std::pair<std::string, unsigned int>> getLinks() const;

        /** \brief adds a link from string s to state id i
         *
         * @param s input string
         * @param i state id
         */
        void addLink(const std::string& s, unsigned int i) const;

        /** \brief operator <
         *
         * @param lhs left side
         * @param rhs right side
         * @return lhs < rhs
         */
        friend bool operator<(const State& lhs, const State& rhs);

        /** \brief operator ==
         *
         * @param lhs left side
         * @param rhs right side
         * @return lhs == rhs
         */
        friend bool operator==(const State& lhs, const State& rhs);

        /** \brief operator >
         *
         * @param lhs left side
         * @param rhs right side
         * @return lhs > rhs
         */
        friend bool operator>(const State& lhs, const State& rhs);
};

#endif // SERA_STATE_H
