#include "Table.h"
#include "../../single_include/tmtoon/usefulFunctions.hpp"
#include "../Actions/End/Accept.h"
#include "../Actions/End/Error.h"
#include "../Actions/Goto/Goto.h"
#include "../Actions/Reduce/Reduce.h"
#include "../Actions/Shift/Shift.h"
#include "State.h"
#include <algorithm>
#include <fstream>
#include <map>

Table::Table(CFG& c) : c(c)
{
        // get terminals: needed for insertionRule
        terminals = c.getTerminals();
        c.addTerminal("$");

        // First: create a new start state with EOS that goes like this: S' -> "S", "$"
        const std::string& start1 = c.getStartState();
        const std::string& start = start1 + "'";

        //    productions.push_back(new Production(start, {start1, "$"})); // use a local productions vector to keep the
        //    CFG const
        Production* S = new Production(start, {start1, "$"});

        // Second: create state 0, with the 3rd component
        std::vector<State> states;
        std::vector<LrItem> items;
        std::set<std::string> set;

        // Create the first item
        set.emplace("$");
        LrItem item1 = LrItem(S->getHead(), S->getBody(), set); // follow of first item = "$"

        // The other items will be the closure of item 1
        std::vector<LrItem> closure = Closure(item1);
        std::move(closure.begin(), closure.end(), std::inserter(items, items.end()));

        // Create the state
        State* state0 = new State(items, 0);

        // Then: calculate the closure for each LrItem, moving the marker.
        states = generateStates(state0);

        // Create table from the states
        createTable(states);
}

void Table::toHTML(const std::string& filename)
{
        // open file
        std::ofstream out(filename);

        // start table
        out << "<TABLE BORDER = \"5\">" << std::endl;

        // draw follow row (empty corner followed by the symbols
        out << "    <TR>" << std::endl;
        out << "        <TD></TD>" << std::endl; // the empty corner
        for (const auto& t : symbols) {
                out << "        <TD style='text-align:center'>" << t << "</TD>" << std::endl;
        }
        out << "    </TR>" << std::endl;

        // go over the rows
        for (unsigned int i = 0; i < table.size(); ++i) {
                const auto& row = table[i];
                out << "    <TR>" << std::endl;

                // every row starts with the state ID
                out << "        <TD style='text-align:center'>" << i << "</TD>" << std::endl;

                // every column has a terminal
                for (unsigned int j = 0; j < symbols.size(); ++j) {
                        //            const auto& t = symbols[j]; // terminal
                        out << "        <TD style='text-align:center'>";
                        out << row[j]->str();
                        out << "</TD>" << std::endl;
                }
                out << "    </TR>" << std::endl;
        }
        out << "</TABLE>" << std::endl;
        out.close();
}

Action* Table::get(const unsigned int state, const std::string& terminal)
{
        const unsigned int i = state;
        unsigned int j = 0;
        if (std::find(symbols.begin(), symbols.end(), terminal) != symbols.end()) {
                j = std::find(symbols.begin(), symbols.end(), terminal) - symbols.begin();
        } else {
                return nullptr;
        }

        return table[i][j];
}

void Table::set(const unsigned int state, const std::string& terminal, Action* value)
{
        const unsigned int i = state;
        unsigned int j = 0;
        if (std::find(symbols.begin(), symbols.end(), terminal) != symbols.end()) {
                j = std::find(symbols.begin(), symbols.end(), terminal) - symbols.begin();
        } else {
                return;
        }

        if (table[i][j]->str() == "") {
                delete table[i][j];
                table[i][j] = value;
        } else {
                std::cerr << "Trying to overwrite value in table -> maybe this CFG doesn't have a table with the "
                             "selected version of LR parsing?"
                          << std::endl;
                std::cerr << table[i][j]->str() << " and " << value->str() << " on location " << std::to_string(i)
                          << ", " << terminal << std::endl;
        }
}

const std::vector<std::string>& Table::getSymbols() const { return symbols; }

void Table::setSymbols(const std::vector<std::string>& symbol) { Table::symbols = symbol; }

const std::vector<std::vector<Action*>>& Table::getTable() const { return table; }

void Table::setTable(const std::vector<std::vector<Action*>>& table) { Table::table = table; }

void Table::createTable(const std::vector<State>& states)
{
        // Last: Make the table out of all the states.
        // 0. create vector 'symbols'
        symbols.insert(symbols.end(), c.getTerminals().begin(), c.getTerminals().end());
        symbols.insert(symbols.end(), c.getVariables().begin(), c.getVariables().end());

        // 1. fill table with ERROR
        for (unsigned int i = 0; i < states.size(); ++i) {
                std::vector<Action*> row;
                for (unsigned int j = 0; j < symbols.size(); ++j) {
                        row.emplace_back(new Error());
                }
                table.push_back(row);
        }

        unsigned int i = 0;
        for (const auto& s : states) {
                for (const auto& l : s.getItems()) {
                        // 2. add accept
                        if (l.getMarked() == "$") {
                                this->set(i, "$", new Accept());
                        }

                        // 3. add reduce
                        if (l.getMarked() == "") {
                                for (const auto& la : l.getLookahead()) {
                                        this->set(i, la, new Reduce(l.getRhs(), l.getLhs()));
                                }
                        }
                }

                // 4. add shift & goto
                for (const auto& l : s.getLinks()) {
                        if (std::find(c.getTerminals().begin(), c.getTerminals().end(), l.first) !=
                            c.getTerminals().end()) {
                                this->set(i, l.first, new Shift(l.second));
                        } else {
                                this->set(i, l.first, new Goto(l.second));
                        }
                }
                ++i;
        }
}

std::set<std::string> Table::GetFirst(std::vector<std::string> prodBody, std::set<std::string> firsts)
{
        // basisgeval als we een terminal of een epsilon tegenkomen
        if ((std::find(c.getTerminals().begin(), c.getTerminals().end(), prodBody[0]) != c.getTerminals().end()) or
            prodBody[0] == "") {
                firsts.emplace(prodBody[0]);
                return firsts;
        } else {
                // Gaat alle mogelijke producties van een variabele controleren op de follow (rekening gehouden met als
                // die productie tot epsilon leid)
                std::vector<Production*> ProductionsFromVariable = GetProductionsFromVariable(prodBody[0]);
                for (const auto& item : ProductionsFromVariable) {
                        if (item->getHead() != item->getBody()[0]) {
                                std::set<std::string> tempVec = GetFirst(item->getBody(), firsts);
                                for (auto item2 : tempVec) {

                                        if (item2 == "" and prodBody.size() >= 2) {
                                                prodBody.erase(prodBody.begin());
                                                std::set<std::string> tempvec2 = GetFirst(prodBody, firsts);
                                                for (auto item3 : tempvec2) {
                                                        firsts.emplace(item3);
                                                }
                                        }
                                        firsts.emplace(item2);
                                }
                        }
                }
        }
        return firsts;
}

std::vector<Production*> Table::GetProductionsFromVariable(std::string input)
{
        std::vector<Production*> result;
        for (auto prod : c.getProductions()) {
                if (prod->getHead() == input) {
                        result.push_back(prod);
                }
        }
        return result;
}

std::vector<LrItem> Table::Closure(const LrItem& i)
{
        std::set<LrItem> closureSetA;
        std::set<LrItem> closureSetB;
        return Closure(i, closureSetA, closureSetB);
}

std::vector<LrItem> Table::Closure(const LrItem& i, std::set<LrItem>& set, std::set<LrItem>& visited)
{
        const auto& Marked = i.getMarked();

        // Rule 1: Closure(I) contains I
        set.emplace(i);

        // Rule 2: A -> a.Bc then B -> x is also in Closure(I)
        if (std::find(visited.begin(), visited.end(), i) == visited.end()) {
                for (unsigned int j = 0; j < c.getProductions().size(); ++j) {
                        const auto& p = c.getProductions()[j];

                        // If the left side of a production is the marked item, append it's closure to the set
                        if (p->getHead() == Marked) {
                                visited.emplace(i);
                                std::vector<std::vector<std::string>> first;
                                first = i.getNextFirst();
                                std::set<std::string> fullFirst;
                                for (const auto& smallFirst : first) {
                                        for (const auto& s : GetFirst(smallFirst)) {
                                                fullFirst.emplace(s);
                                        }
                                }
                                Closure(LrItem(p->getHead(), p->getBody(), fullFirst), set, visited);
                        }
                }
        }

        simplifySet(set);
        // Returns a vector of the set
        return std::vector<LrItem>(set.begin(), set.end());
}

std::vector<State> Table::generateStates(const State* s, std::set<const State*>& set, std::vector<LrItem>& visited,
                                         std::vector<std::pair<std::set<LrItem>, unsigned int>>& links)
{
        // State s is a part of the set of states.
        set.emplace(s);

        // Pick an item and move the marker
        std::map<std::string, std::set<LrItem>> map;
        for (unsigned int i = 0; i < s->getItems().size(); ++i) {
                std::string marked = s->getItems()[i].getMarked();
                std::vector<LrItem> closure;
                std::set<LrItem> tmpVisited;
                if (not find(visited, s->getItems()[i])) {
                        for (unsigned int j = 0; j < s->getItems().size(); ++j) {
                                if (s->getItems()[j].getMarked() == marked) {
                                        LrItem newItem = s->getItems()[j];
                                        visited.push_back(newItem);
                                        tmpVisited.emplace(newItem);
                                        if (newItem.moveMarker()) {
                                                std::vector<LrItem> tmp = Closure(newItem);
                                                closure.insert(closure.end(), tmp.begin(), tmp.end());
                                        }
                                }
                        }
                        if (not closure.empty()) {
                                // add visited & links here
                                links.emplace_back(tmpVisited, set.size());
                                s->addLink(marked, set.size());
                                generateStates(new State(closure, set.size()), set, visited, links);
                        }
                } else {
                        // Als het item gevonden is, groepeer het met alle items in deze state die de zelfde input nodig
                        // hebben om later te linken
                        map[marked].emplace(s->getItems()[i]);
                }
        }

        // link de waardes in de map
        for (const auto& m : map) {
                for (const auto& l : links) {
                        // Als het een bestaande groep is -> link
                        if (m.second == l.first) {
                                s->addLink(m.first, l.second);
                        }
                }
        }

        // Returns a vector of the set
        std::set<State> vec; // has to go through set to get sorted again
        for (const auto* val : set) {
                vec.emplace(*val);
        }
        return std::vector<State>(vec.begin(), vec.end());
}

std::vector<State> Table::generateStates(const State* s)
{
        std::set<const State*> setA;
        std::vector<LrItem> setB;
        std::vector<std::pair<std::set<LrItem>, unsigned int>> setC;
        return generateStates(s, setA, setB, setC);
}

std::vector<std::string> Table::GetFollow(const std::string& Variable, std::set<std::string>& Visited)
{
        std::set<std::string> result;
        // start state
        if (Variable == c.getStartState()) {
                result.emplace("$");
        }
        // alle producties overlopen
        for (auto Prod : c.getProductions()) {

                // gevallen van de vorm alpha A beta dan is de follow van A de first van beta
                if (Prod->getBody().size() >= 2) {
                        for (unsigned int i = 0; i < Prod->getBody().size(); i++) {
                                // controle of het wel geldig is
                                if ((std::find(c.getVariables().begin(), c.getVariables().end(), Prod->getBody()[i]) !=
                                     c.getVariables().end()) and
                                    Prod->getBody()[i] == Variable and i != Prod->getBody().size() - 1) {
                                        std::vector<std::string> beta;
                                        for (unsigned int j = i + 1; j < Prod->getBody().size(); j++) {
                                                beta.push_back(Prod->getBody()[j]);
                                        }
                                        std::set<std::string> aidingVec;
                                        std::set<std::string> tempResult = GetFirst(beta, aidingVec);
                                        for (const auto& item : tempResult) {
                                                result.emplace(item);
                                        }
                                }
                        }

                        // Als de beta een productie is die naar epsilon gaat
                        if (Prod->getBody()[Prod->getBody().size() - 2] == Variable and
                            (std::find(c.getVariables().begin(), c.getVariables().end(),
                                       Prod->getBody()[Prod->getBody().size() - 1]) != c.getVariables().end())) {
                                for (auto Prod2 : c.getProductions()) {
                                        if (Prod2->getHead() == Prod->getBody().back() and Prod2->getBody()[0] == "") {
                                                if (std::find(Visited.begin(), Visited.end(), Prod->getHead()) !=
                                                    Visited.end()) {
                                                        std::vector<std::string> tempvec =
                                                            GetFollow(Prod->getHead(), Visited);
                                                        for (auto item : tempvec) {
                                                                result.emplace(item);
                                                        }
                                                        Visited.emplace(Prod->getHead());
                                                }
                                        }
                                }
                        }
                }
                // Als we iets van de vorm alpha A hebben
                if (Prod->getBody().size() >= 2) {
                        if (Prod->getHead() != Variable and Prod->getBody().back() == Variable) {
                                if (std::find(Visited.begin(), Visited.end(), Prod->getHead()) != Visited.end()) {
                                        Visited.emplace(Prod->getHead());
                                        std::vector<std::string> tempvec = GetFollow(Prod->getHead(), Visited);
                                        for (auto item : tempvec) {
                                                result.emplace(item);
                                        }
                                }
                        }
                }
        }

        return std::vector<std::string>(result.begin(), result.end());
}

std::set<std::string> Table::GetFirst(std::vector<std::string> prodBody)
{
        std::set<std::string> firsts;
        return GetFirst(prodBody, firsts);
}

void Table::simplifySet(std::set<LrItem>& set)
{
        std::vector<LrItem> tmp(set.begin(), set.end());
        for (unsigned int i = 0; i < tmp.size(); ++i) {
                auto& a = tmp[i];
                for (const auto& b : set) {
                        if (a.weakEq(b) and a != b) {
                                a.addLookahead(b.getLookahead());
                        }
                }
        }
        set = std::set<LrItem>(tmp.begin(), tmp.end());
}

const std::vector<std::string>& Table::getTerminals() const { return terminals; }
