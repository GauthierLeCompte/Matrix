#include "LR.h"
#include "../../single_include/tmtoon/usefulFunctions.hpp"
#include <string>

LR::LR(CFG& c, std::ofstream& os) : file(os)
{
        Table* t = new Table(c);
        setParseTable(t);
}

void LR::parse(std::vector<std::string> input, bool print)
{
        for (const auto& i : input) {
                if (not find(getParseTable()->getSymbols(), i)) {
                        std::cerr << "ERROR: inputvalue not in alphabet" << std::endl;
                        return;
                }
        }

        std::vector<std::string> stack = {"0"};
        input.push_back("$");
        file << "<Table BORDER = \"0\">\n";
        parse2(stack, input, true, print);
        file << "</Table>\n\n";
}

void LR::parse2(std::vector<std::string>& stack, std::vector<std::string>& input, bool debug, bool print)
{
        if (rejecting) {

                rejectingVar = {stack};
                rejectingVar.push_back(input);

                return;
        } else if (accepting) {
                return;
        } else {
                if (validStack(stack)) {
                        if (debug) {
                                printMoment(stack, input);
                        }
                        std::string firstInput = input[0];

                        for (unsigned int i = 0; i < this->getParseTable()->getSymbols().size(); ++i) {
                                if (this->getParseTable()->getSymbols()[i] == firstInput) {

                                        rejecting =
                                            this->getParseTable()->getTable()[topOfStack(stack)][i]->isRejecting();
                                        accepting =
                                            this->getParseTable()->getTable()[topOfStack(stack)][i]->isAccepting();
                                        this->getParseTable()->getTable()[topOfStack(stack)][i]->execute(stack, input,
                                                                                                         file, print);
                                        break;
                                }
                        }
                } else {
                        int lastIndex = std::stoi(stack[stack.size() - 2]);
                        int lastTerminal = 0;

                        for (unsigned int i = 0; i < this->getParseTable()->getSymbols().size(); ++i) {
                                if (stack.back() == this->getParseTable()->getSymbols()[i]) {
                                        lastTerminal = i;
                                        break;
                                }
                        }

                        rejecting = this->getParseTable()->getTable()[lastIndex][lastTerminal]->isRejecting();
                        accepting = this->getParseTable()->getTable()[lastIndex][lastTerminal]->isAccepting();
                        this->getParseTable()->getTable()[lastIndex][lastTerminal]->execute(stack, input, file, print);
                }
                return parse2(stack, input, debug, print);
        }
}

bool LR::validStack(std::vector<std::string> stack)
{
        std::string top = stack.back();

        return !(std::find(this->getParseTable()->getSymbols().begin(), this->getParseTable()->getSymbols().end(),
                           top) != this->getParseTable()->getSymbols().end());
}

int LR::topOfStack(std::vector<std::string> stack) { return std::stoi(stack[stack.size() - 1]); }

Table* LR::getParseTable() const { return parseTable; }

void LR::setParseTable(Table* parseTable) { LR::parseTable = parseTable; }

std::vector<std::string> LR::getStack() const { return stack; }

void LR::setStack(std::vector<std::string> stack) { LR::stack = stack; }

void LR::printMoment(const std::vector<std::string>& stack, const std::vector<std::string>& input)
{
        file << "     <TR>\n        <TD>$";
        for (const auto& s : stack) {
                file << s;
        }
        file << "</TD>\n        <TD style='text-align:right'>";
        for (const auto& i : input) {
                file << i;
        }
        file << "</TD>\n    </TR>\n";
}

std::vector<std::vector<std::string>> LR::getRejectingVar() { return rejectingVar; }

bool LR::isRejecting() const { return rejecting; }

bool LR::isAccepting() const { return accepting; }

void LR::setRejecting(bool rejecting) { LR::rejecting = rejecting; }

void LR::setAccepting(bool accepting) { LR::accepting = accepting; }

LR::~LR() { file.close(); }

void LR::reset()
{
        rejectingVar.clear();
        setAccepting(false);
        setRejecting(false);
}
