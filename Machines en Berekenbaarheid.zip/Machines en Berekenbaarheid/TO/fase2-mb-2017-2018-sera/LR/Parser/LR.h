#ifndef LR_LR_H
#define LR_LR_H

#include "../../CFG/CFG.h"
#include "../Actions/Action.h"
#include "../Table/Table.h"
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>

class LR
{
private:
        Table* parseTable;

        std::vector<std::string> stack;

        std::vector<std::vector<std::string>> rejectingVar = {};

        bool rejecting = false;

        bool accepting = false;

public:
        /**
         * ofstream file
         */
        std::ofstream& file;

        /**
         * Constructor for LR
         * @param c Contect Free Grammer
         * @param s offstream file
         */
        LR(CFG& c, std::ofstream& s);

        /**
         * Destructor for LR
         */
        ~LR();

        /**
         * First parse function, calls the parse2 function recursively
         * @param input remaining input
         * @param print if we want to print or not
         */
        void parse(std::vector<std::string> input, bool print = true);

        /**
         *
         * @param i input
         * @param s stack
         * @param debug if we want to debug output or not (extended output)
         * @param print if we want to print or not
         */
        void parse2(std::vector<std::string>& i, std::vector<std::string>& s, bool debug, bool print);

        /**
         * Checks if a stack is valid
         * @param stack Current stack
         * @return true or false
         */
        bool validStack(std::vector<std::string> stack);

        /**
         * Returns top of stack
         * @param stack Current stack
         * @return top of stack as integer
         */
        int topOfStack(std::vector<std::string> stack);

        /**
         * prints moment
         * @param stack current stack
         * @param input remaining input
         */
        void printMoment(const std::vector<std::string>& stack, const std::vector<std::string>& input);

        /**
         * Get rejecting variable
         * @return
         */
        std::vector<std::vector<std::string>> getRejectingVar();

        /**
         * Returns parsetable
         * @return Table object
         */
        Table* getParseTable() const;

        /**
         * Set parse table
         * @param parseTable Table object
         */
        void setParseTable(Table* parseTable);

        /**
         * Returns stack
         * @return the stack
         */
        std::vector<std::string> getStack() const;

        /**
         * Set a new stack
         * @param stack new stack
         */
        void setStack(std::vector<std::string> stack);

        /**
         * Set rejecting
         * @param rejecting true or false
         */
        void setRejecting(bool rejecting);

        /**
         * set accepting
         * @param accepting true or false
         */
        void setAccepting(bool accepting);

        /**
         * Check if rejecting
         * @return true or false
         */
        bool isRejecting() const;

        /**
         * Check if is accepting
         * @return true or false
         */
        bool isAccepting() const;

        /**
         * Resets LR
         */
        void reset();
};

#endif // LR_LR_H
